<?php
    
    class TdocumentoController{
        private $model;
        private $envioemail;
        
        
        public function __construct(){
            $this->model=new TdocumentoModel();
        }
        
        public function set($data=array()){
            return  $this->model->set($data);
        }
        
        public function get($data =''){
             return  $this->model->get($data);
        }
        
        public function getlista($data =''){
             return  $this->model->getlista($data);
        }
        
        public function del($data =''){
             return  $this->model->del($data);
        }
        public function edit($data=array()){
             return  $this->model->edit($data);
        }
        
        public function queryBuscar($data =''){
            return  $this->model->queryBuscar($data);
        }
        
        
    }
?>
