<?php
    
    class OrdenestiendaController{
        private $model;
        private $envioemail;
        
        
        public function __construct(){
            $this->model=new OrdenestiendaModel();
        }
        
        public function set($facti_data=array()){
            return  $this->model->set($facti_data);
        }
        public function get($facturasti =''){
             return  $this->model->get($facturasti);
        }
        public function getE($facturasti =''){
             return  $this->model->getE($facturasti);
        }
        public function getEle($facturasti =''){
             return  $this->model->getEle($facturasti);
        }
        public function setCabecera($facti_data=array()){
            return  $this->model->setCabecera($facti_data);
        }
        public function del($facturasti =''){
             return  $this->model->del($facturasti);
        }
        public function ultfac(){
            return  $this->model->ultfac();
        }
        public function ultfacTI(){
            return  $this->model->ultfacTI();
        }
        public function getContenido($facturasti =''){
             return  $this->model->getContenido($facturasti);
        }
        public function edit($facturasti_data=array()){
            $para='arias212@hotmail.com';
            $asunto='facti modificado: '.$facturasti_data['descripcion'];
            $textomail='facti: '.$facturasti_data['numdoc'].' modificado con exito por el usuario: '.$_SESSION['idemp'];
            $v2='From: Fcicweb/'.$_SESSION['idemp'].'<soporte@fciempresas.com>\r\n';
            $v2.='MIME-Version: 1.0\r\n';
            $v2.='Content-type text/html; charset=iso-8859-1\r\n';
            $exito = mail($para,$asunto, $textomail, $v2);
            
             return  $this->model->edit($facturasti_data);
        }
        public function pendiente(){
            return  $this->model->pendiente();
        }
        
        public function actualizaPendientes(){
            return  $this->model->actualizaPendientes();
        }
        
        public function queryBuscar($facturasti =''){
            return  $this->model->queryBuscar($facturasti);
        }
        
        public function arqueoDia(){
            return  $this->model->arqueoDia();
        }
        //metodos de facuracion 
        public function contenidoTemporal($usuario,$tipodoc){
            return  $this->model->contenidoTemporal($usuario,$tipodoc);
        }
        public function articulosPendientes(){
            return  $this->model->articulosPendientes();
        }
        public function setcontenido($data=array()){
            return  $this->model->setcontenido($data);
        }
        public function getTpago($data=array()){
            return  $this->model->getTpago($data);
        }
        public function updContenido($data=array()){
            return  $this->model->updContenido($data);
        }
        
        public function udpOrdenestienda($data=array()){
            return  $this->model->udpOrdenestienda($data);
        }
        public function udpOrdenestiendaPagos($data=array()){
            return  $this->model->udpOrdenestiendaPagos($data);
        }
//-------------------Consultas   
        public function facturaNit($facturasti =''){
             return  $this->model->facturaNit($facturasti);
        }
        public function facturaNumdoc($facturasti =''){
             return  $this->model->facturaNumdoc($facturasti);
        }
        public function facturaCaja($facturasti =''){
             return  $this->model->facturaCaja($facturasti);
        }
        public function facturaFecha($ini,$fin){
             return  $this->model->facturaFecha($ini,$fin);
        }
        public function getCodigo($codigo){
             return  $this->model->getCodigo($codigo);
        }
        public function getBodega($codigo){
             return  $this->model->getBodega($codigo);
        }
        public function getContenidoNumdoc($codigo){
             return  $this->model->getContenidoNumdoc($codigo);
        }
        public function getCodigoFecha($codigo,$ini,$fin){
             return  $this->model->getCodigoFecha($codigo,$ini,$fin);
        }
        public function getNitFecha($nit,$ini,$fin){
             return  $this->model->getNitFecha($nit,$ini,$fin);
        }
        public function getFecha($ini,$fin){
             return  $this->model->getFecha($ini,$fin);
        }
        public function getBodegaFecha($bodega,$ini,$fin){
             return  $this->model->getBodegaFecha($bodega,$ini,$fin);
        }
        public function getCajaFecha($caja,$ini,$fin){
             return  $this->model->getCajaFecha($caja,$ini,$fin);
        }
        public function getVendedorFecha($vendedor,$ini,$fin){
             return  $this->model->getVendedorFecha($vendedor,$ini,$fin);
        }
        public function getGrupoFecha($grupo,$ini,$fin){
             return  $this->model->getGrupoFecha($grupo,$ini,$fin);
        }
        public function getLineaFecha($linea,$ini,$fin){
             return  $this->model->getLineaFecha($linea,$ini,$fin);
        }
        public function getCiudadFecha($ciudad,$ini,$fin){
             return  $this->model->getCiudadFecha($ciudad,$ini,$fin);
        }
        public function getPendientePago($facturasti =''){
             return  $this->model->getPendientePago($facturasti);
        }
//Insertar cabecera
    
        public function setPFacturasTi($data=array()){
            return  $this->model->setPFacturasTi($data);
        }
        public function inserUltfac(){
            return  $this->model->ultfac();
        }
        public function trasladoContenido($numfac,$usuario,$tipodoc){
            return  $this->model->trasladoContenido($numfac,$usuario,$tipodoc);
        }
        public function xmlUltfac($numfac){
             return  $this->model->xmlUltfac($numfac);
        }
        public function delConTem($usuario,$tipodoc){
            return  $this->model->delConTem($usuario,$tipodoc);
        }
        
        public function eliminarTemporal($accion,$codigo,$tipodoc,$usuario,$descuento){
            return  $this->model->eliminarTemporal($accion,$codigo,$tipodoc,$usuario,$descuento);
        }
        public function updateArticulo($usuario,$tipodoc){
            return  $this->model->updateArticulo($usuario,$tipodoc);
        }
//Iva terceros        
        public function ivater($fac=''){
             return  $this->model->ivater($fac);
        }
        
        public function setPagoRespuesta($facti_data=array()){
            return  $this->model->setPagoRespuesta($facti_data);
        }
        
        public function setPagoManual($facti_data=array()){
            return  $this->model->setPagoManual($facti_data);
        }
        
        public function getPago($facturasti =''){
             return  $this->model->getPago($facturasti);
        }
        
        public function detalleTiendaOnline($facturasti ='',$numdoc=''){
             return  $this->model->detalleTiendaOnline($facturasti,$numdoc);
        }
    }
?>
