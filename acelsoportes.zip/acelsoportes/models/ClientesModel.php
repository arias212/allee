<?php
    
    class ClientesModel extends Model{

        
        public function set($clientes_data = array()){
            
            foreach($clientes_data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }  
        $nombre=strtoupper($nombre);
        $apellido=strtoupper($apellido);
        $reprelegal=strtoupper($reprelegal);
        $contacto1=strtoupper($contacto1);
        $contacto2=strtoupper($contacto2);
        $cargo1=strtoupper($cargo1);
        $cargo2=strtoupper($cargo2);
        $departamento=substr($ciudad, 0, 2); 
        $usuario=$_SESSION['acceso'];
        
           $this->query = "INSERT INTO nits SET regn=0,tipo=?,nit=?,puntov=?,nombre=?,direccion=?,
                            regiment=?,fax=?,telefonos=?,ciudad=?, email1=?,email2=?,
                            contacto1=?,contacto2=?,cargo1=?,cargo2=?,observaciones=?,
                            tope=?, diascredito=?, vendedor=?, reprelegal=?, cre=?,dv=?, tdocumento=?, departamento=?, tpersona=?,apellido=? "; 
            
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("iissssssssssssssdisssiisis",$tipo,$nit,$puntov,$nombre,$direccion,$regiment,$fax,$telefonos,$ciudad,$email1,$email2,
                                        $contacto1,$contacto2,$cargo1,$cargo2,$observaciones,$tope,$diascredito,$vendedor,$reprelegal,$usuario,$dv,$tdocumento,
                                        $departamento,$tpersona,$apellido);
            $this->preparar->execute();
            $this->origen="Cliente";
            $this->actividad="Creado";
            $this->objeto=$nombre;
                if($this->preparar->affected_rows != -1){
                     
                }else{
                    echo '<div class="centrar">
                            <h3 class="resaltaralerta">No se realizo la operacion,<br> Es posible que el tercero ya exista</h3>
                        </div>';
                }   
            $this->preparar->free_result();
            $this->conn->close();
        }
        
        public function setRapido($clientes_data = array()){
            
            foreach($clientes_data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }  
        $nombre=strtoupper($nombre);
        $apellido=strtoupper($apellido);
        //$reprelegal=strtoupper($reprelegal);
        //$contacto1=strtoupper($contacto1);
        //$contacto2=strtoupper($contacto2);
        //$cargo1=strtoupper($cargo1);
        //$cargo2=strtoupper($cargo2);
        $departamento=substr($ciudad, 0, 2); 
        $rfiscal=($tpersona==1)?48:$rfiscal;
        
           $this->query = "INSERT INTO nits SET regn=0,tipo='0',nit=?,puntov=?,nombre=?,apellido=?,direccion=?,
                            regiment=?,fax='',telefonos=?,ciudad=?, email1=?,email2='',
                            contacto1='',contacto2='',cargo1='',cargo2='',observaciones='Cliente rapido',
                            tope='', diascredito='', vendedor='', reprelegal=?, cre=?,dv=?, tdocumento=?, departamento=?, tpersona=? "; 
            
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("sisssssssssiisi",$nit,$puntov,$nombre,$apellido,$direccion,$rfiscal,$telefono,$ciudad,$email,$reprelegal,$usuario,
                                        $dv,$tdocumento,$departamento,$tpersona);
            $this->preparar->execute();
            $this->origen="Cliente";
            $this->actividad="Creado";
            $this->objeto=$nombre;
                if($this->preparar->affected_rows != -1){
                    echo '<div class="centrar">
                                <h3 class="titulo">Tercero guardado con exito </h3>
                            </div> '; 
                }else{
                    echo '<div class="centrar">
                            <h3 class="resaltaralerta">No se realizo la operacion,<br> Es posible que el tercero ya exista</h3>
                        </div>';
                }   
            $this->preparar->free_result();
            $this->conn->close();
        }        
         
        public function get($cliente = ''){
            $this->db_open();
            $cliente = $this->conn->real_escape_string($cliente);
            if($this->query=($cliente != '')){
                $this->query="SELECT cli.regn,cli.tipo,cli.nit,cli.puntov,cli.centroc,cli.nombre,cli.reprelegal,cli.direccion,cli.regiment,
                                cli.fax,cli.telefonos,cli.ciudad,cli.email1,cli.email2,cli.contacto1,cli.contacto2,cli.cargo1,cli.cargo2,cli.vendedor,
                                cli.observaciones,cli.facturado,cli.diascredito,cli.fechacre,cli.fechagrab,cli.topereten,cli.retenenfact,cli.usuario,
                                cli.tope,tbc.descripcion AS descrip, cli.dv, cli.tdocumento, cli.tpersona, cli.apellido
                        FROM nits AS cli 
                        LEFT JOIN tablas AS tbc ON cli.ciudad = tbc.codigo  
                        WHERE cli.regn='$cliente'
                        ORDER BY cli.nombre 
                        LIMIT 0,20";
                $this->get_query();
            }else{            
                $this->query="SELECT cli.regn,cli.tipo,cli.nit,cli.puntov,cli.centroc,cli.nombre,cli.reprelegal,cli.direccion,cli.regiment,
                                cli.fax,cli.telefonos,cli.ciudad,cli.email1,cli.email2,cli.contacto1,cli.contacto2,cli.cargo1,cli.cargo2,cli.vendedor,
                                cli.observaciones,cli.facturado,cli.diascredito,cli.fechacre,cli.fechagrab,cli.topereten,cli.retenenfact,cli.usuario,
                                cli.tope,tbc.descripcion AS descrip,cli.dv, cli.tdocumento, cli.tpersona , cli.apellido , cli.apellido
                        FROM nits AS cli 
                        LEFT JOIN tablas AS tbc ON cli.ciudad = tbc.codigo  
                        ORDER BY cli.nombre 
                        LIMIT 0,10";
                        $this->get_query();
            }
 
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            if(!empty($data)){
                return $data;
            }
        
        }
        
        public function getNit($cliente){
            $this->db_open();
            $cliente = $this->conn->real_escape_string($cliente);

            $this->query="SELECT cli.regn,cli.tipo,cli.nit,cli.puntov,cli.centroc,cli.nombre,cli.reprelegal,cli.direccion,cli.regiment,
                            cli.fax,cli.telefonos,cli.ciudad,cli.email1,cli.email2,cli.contacto1,cli.contacto2,cli.cargo1,cli.cargo2,cli.vendedor,
                            cli.observaciones,cli.facturado,cli.diascredito,cli.fechacre,cli.fechagrab,cli.topereten,cli.retenenfact,cli.usuario,
                            cli.tope,tbc.descripcion AS descrip,cli.dv, cli.tdocumento, cli.tpersona , cli.apellido
                    FROM nits AS cli 
                    LEFT JOIN tablas AS tbc 
                    ON cli.ciudad = tbc.codigo  
                    WHERE cli.nit = '$cliente' 
                    ORDER BY cli.nombre ";
                $this->get_query();
            
 
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            if($num_registros=count($this->rows)){
                return $data;
            }
        
        }
        
        public function queryBuscar($cliente = ''){
            $this->db_open();
            $cliente = $this->conn->real_escape_string($cliente);
            $this->query=($cliente != '')
                ?"SELECT DISTINCTROW cli.regn, cli.tipo,cli.nit,cli.puntov,cli.centroc,cli.nombre,cli.reprelegal,cli.direccion,cli.regiment,cli.fax,cli.telefonos,cli.ciudad,			
                                    cli.email1,cli.email2,cli.contacto1,cli.contacto2,cli.cargo1,cli.cargo2,cli.vendedor,cli.observaciones,			
                                    cli.facturado,cli.diascredito,cli.fechacre,cli.fechagrab,cli.topereten,cli.retenenfact,cli.usuario,cli.tope,tbc.descripcion,
                                    cli.dv, cli.tdocumento, cli.tpersona , cli.apellido
                        FROM nits  cli 
                        LEFT JOIN tablas tbc 
                        ON cli.ciudad = tbc.codigo  
                        WHERE cli.nit LIKE '%$cliente%' OR cli.nombre LIKE'%$cliente%' OR cli.reprelegal LIKE '%$cliente%' OR cli.regn='$cliente' OR cli.contacto1 LIKE '%$cliente%'
                        ORDER BY cli.nombre"
                :"SELECT DISTINCTROW cli.regn,cli.tipo,cli.nit,cli.puntov,cli.centroc,cli.nombre,cli.reprelegal,cli.direccion,cli.regiment,cli.fax,cli.telefonos,cli.ciudad,			
                                    cli.email1,cli.email2,cli.contacto1,cli.contacto2,cli.cargo1,cli.cargo2,cli.vendedor,cli.observaciones,			
                                    cli.facturado,cli.diascredito,cli.fechacre,cli.fechagrab,cli.topereten,cli.retenenfact,cli.usuario,cli.tope,tbc.descripcion,
                                    cli.dv, cli.tdocumento, cli.tpersona , cli.apellido
                        FROM nits AS cli 
                        LEFT JOIN tablas AS tbc ON cli.ciudad = tbc.codigo  
                        ORDER BY cli.nombre 
                        LIMIT 0,10";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            if(!empty($data)){
                return $data;
            }
        
        }
      
        public function del($regn=''){
            $this->db_open();
            $regn = $this->conn->real_escape_string($regn);
            $this->query = "DELETE FROM nits WHERE regn ='$regn'";
            $this->set_query(); 
            $this->origen="Cliente";
            $this->actividad="Elimina";
            $this->objeto=$regn;
        }
        
        public function edit($clientes_data = array()){
            
            foreach($clientes_data as $key=>$value){
                $$key=$value;
            } 
            $nombre=strtoupper($nombre);
            $apellido=strtoupper($apellido);
            $reprelegal=strtoupper($reprelegal);
            $contacto1=strtoupper($contacto1);
            $contacto2=strtoupper($contacto2);
            $cargo1=strtoupper($cargo1);
            $cargo2=strtoupper($cargo2);
            $departamento=substr($ciudad, 0, 2);  
            $this->query = "UPDATE nits SET tipo=?,nit=?,puntov=?,nombre=?,direccion=?,
                            regiment=?,fax=?,telefonos=?,ciudad=?, email1=?,email2=?,
                            contacto1=?,contacto2=?,cargo1=?,cargo2=?,observaciones=?,
                            tope=?, diascredito=?, vendedor=?, reprelegal=?, cre=?,dv=?, tdocumento=?, departamento=?, tpersona=?,apellido=? 
                            WHERE regn=?"; 
            $this->origen="Cliente";
            $this->actividad="Creado";
            $this->objeto=$nombre;
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("isssssssssssssssdisssisiisi",$tipo,$nit,$puntov,$nombre,$direccion,$regiment,$fax,$telefonos,$ciudad,$email1,$email2,
                                        $contacto1,$contacto2,$cargo1,$cargo2,$observaciones,$tope,$diascredito,$vendedor,$reprelegal,$usuario,$dv,$tdocumento,
                                        $departamento,$tpersona,$apellido,$regn);
            $this->preparar->execute();
            $this->origen="Tercero";
            $this->actividad="Modificar";
            $this->objeto=$nombre;
                if($this->preparar->affected_rows != -1){
                    echo '<div class="centrar">
                                <h3 class="titulo">Tercero modificado con exito </h3>
                            </div> '; 
                }else{
                    echo '<div class="centrar">
                            <h3 class="resaltaralerta">No se realizo la operacion,<br> Es posible que el tercero ya exista</h3>
                        </div>';
                }   
            $this->preparar->free_result();
            $this->conn->close();

        }
        
        public function datos($cliente = ''){
            $this->db_open();
            $cliente = $this->conn->real_escape_string($cliente);
            $this->query=($cliente != '')
                ?"SELECT DISTINCTROW cli.regn, cli.tipo,cli.nit,cli.puntov,cli.centroc,cli.nombre,cli.reprelegal,cli.direccion,cli.regiment,cli.fax,cli.telefonos,cli.ciudad,			
                                    cli.email1,cli.email2,cli.contacto1,cli.contacto2,cli.cargo1,cli.cargo2,cli.vendedor,cli.observaciones,			
                                    cli.facturado,cli.diascredito,cli.fechacre,cli.fechagrab,cli.topereten,cli.retenenfact,cli.usuario,cli.tope,tbc.descripcion,
                                    cli.dv, cli.tdocumento, cli.tpersona , cli.apellido
                        FROM nits  cli 
                        LEFT JOIN tablas tbc ON cli.ciudad = tbc.codigo  
                        WHERE cli.regn='$cliente'
                        GROUP BY cli.nit
                        ORDER BY cli.nombre"
                :"SELECT DISTINCTROW cli.regn,cli.tipo,cli.nit,cli.puntov,cli.centroc,cli.nombre,cli.reprelegal,cli.direccion,cli.regiment,cli.fax,cli.telefonos,cli.ciudad,			
                                    cli.email1,cli.email2,cli.contacto1,cli.contacto2,cli.cargo1,cli.cargo2,cli.vendedor,cli.observaciones,			
                                    cli.facturado,cli.diascredito,cli.fechacre,cli.fechagrab,cli.topereten,cli.retenenfact,cli.usuario,cli.tope,tbc.descripcion,
                                    cli.dv, cli.tdocumento, cli.tpersona , cli.apellido
                        FROM nits AS cli 
                        LEFT JOIN tablas AS tbc ON cli.ciudad = tbc.codigo 
                        WHERE cli.nit != '*' 
                        GROUP BY cli.nit
                        ORDER BY cli.nombre ";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            if(!empty($data)){
                return $data;
            }
        
        }
        
        public function puntov($cliente = ''){
            $this->db_open();
            $cliente = $this->conn->real_escape_string($cliente);
            if($this->query=($cliente != '')){
                $this->query="SELECT cli.regn,cli.tipo, cli.nit, cli.puntov, cli.centroc, cli.nombre
                        FROM nits AS cli 
                        LEFT JOIN tablas AS tbc ON cli.ciudad = tbc.codigo  
                        WHERE cli.nit = '$cliente' 
                        ORDER BY cli.nombre";
                $this->params="'ssss',$cliente,$cliente,$cliente,$cliente" ;
                $this->get_query();
            }else{            
                $this->query="SELECT cli.regn,cli.tipo,cli.nit,cli.puntov,cli.centroc,cli.nombre,cli.reprelegal,cli.direccion,cli.regiment,
                                cli.fax,cli.telefonos,cli.ciudad,cli.email1,cli.email2,cli.contacto1,cli.contacto2,cli.cargo1,cli.cargo2,cli.vendedor,
                                cli.observaciones,cli.facturado,cli.diascredito,cli.fechacre,cli.fechagrab,cli.topereten,cli.retenenfact,cli.usuario,
                                cli.tope,tbc.descripcion AS descrip
                        FROM nits AS cli 
                        LEFT JOIN tablas AS tbc ON cli.ciudad = tbc.codigo  
                        ORDER BY cli.nombre
                        LIMIT 0,10";
                        $this->get_query();
            }
 
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            if($num_registros=count($this->rows)){
                return $data;
            }
        
        }
        
        public function editInfo($cliente_data = array()){
            
            foreach($cliente_data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }
            
        $nombre=strtoupper($nombre);
        $apellido=strtoupper($apellido);
        $razon_social=strtoupper($razon_social);
        $departamento=substr($ciudad, 0, 2); 
        $usuario=$_SESSION['acceso'];    
        $regiment=($tpersona==1)?48:$regiment;    
        $this->query = "UPDATE nits SET tdocumento=? ,tpersona=? ,regiment=? , ciudad=? , reprelegal=? ,puntov=?, nombre=?,
                        apellido=?, usuario=?, departamento=?
                        WHERE nit=?" ;
        $this->db_open();
        $this->preparar=$this->conn->prepare($this->query);
        $this->preparar->bind_param("iiisssssssi",$tdocumento,$tpersona,$regiment,$ciudad,$razon_social,
                                        $puntov,$nombre,$apellido,$usuario,$departamento,$nit);
        $this->preparar->execute();
            if($this->preparar->affected_rows != -1){
                $data=1; 
            }else{
                $data=0; 
            } 
            
        $this->preparar->free_result();
        $this->conn->close();
        return $data;
        }
        
        public function editContac($cliente_data = array()){
            
            foreach($cliente_data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }
            
        $direccion=strtoupper($direccion);
        $contacto=strtoupper($contacto);
        $contacto2=strtoupper($contacto2);
        $usuario=$_SESSION['acceso'];       
        $this->query = "UPDATE nits SET vendedor=? ,direccion=? ,telefonos=? , fax=? , contacto1=? ,cargo1=?, email1=?,
                        contacto2=?, email2=?, cargo2=?, usuario=?
                        WHERE nit=?" ;
        $this->db_open();
        $this->preparar=$this->conn->prepare($this->query);
        $this->preparar->bind_param("sssssssssssi",$vendedor,$direccion,$telefonos,$fax,$contacto,
                                        $cargo,$email1,$contacto2,$email2,$cargo2,$usuario,$nit);
        $this->preparar->execute();
            if($this->preparar->affected_rows != -1){
                $data=1; 
            }else{
                $data=0; 
            } 
            
        $this->preparar->free_result();
        $this->conn->close();
        return $data;
        }
        
        public function editVenta($cliente_data = array()){
            
            foreach($cliente_data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }
            
        $usuario=$_SESSION['acceso'];       
        $this->query = "UPDATE nits SET diascredito=? ,tope=? ,observaciones=? , usuario=?
                        WHERE nit=?" ;
        $this->db_open();
        $this->preparar=$this->conn->prepare($this->query);
        $this->preparar->bind_param("iissi",$diascredito,$topecredito,$observaciones,$usuario,$nit);
        $this->preparar->execute();
            if($this->preparar->affected_rows != -1){
                $data=1; 
            }else{
                $data=0; 
            } 
            
        $this->preparar->free_result();
        $this->conn->close();
        return $data;
        }

        /*public function __destruct(){
            unset($this);
        }*/
   
   
    }
?>