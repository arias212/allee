<?php
    
    class PagosonlineModel extends Model{

        
        public function set($ingefectivo_data = array()){
            
            
        }
        
        public function get($ingefectivo_data = array()){
            
            
        }
      
        public function del($bas=''){      
            
        }
        
        public function edit($ingefectivo_data = array()){
        
        }
        
        public function arqueoDia($fechaini='',$fechafin=''){
            
        }
        
        public function empresa($data = array()){
            foreach($data as $key=>$value){
                $$key=$value;
            }
            
            $this->query = "UPDATE empresas SET logo = '$foto', usuario = '$usuario'"; 
   
            $this->set_query();
            
        }
        
        public function response($data = array()){
            foreach($data as $key=>$value){
                $$key=$value;
            }
            
            
        $this->query = "INSERT INTO pagosonline SET idresponse = ? , referencia = ?" ;
        $this->db_open();
        $usuario=$_SESSION['acceso'];  
        $this->preparar=$this->conn->prepare($this->query);
        $this->preparar->bind_param("ss",$idresponse,$referencia);
        $this->preparar->execute();
        
        $this->preparar->free_result();
        $this->conn->close();
            
        }
        
        public function confiPagosOnline($data = array()){
            foreach($data as $key=>$value){
                $$key=$value;
            }
            $accion;
        if($accion==1){    
            
            $this->query = "UPDATE configuracionpagosonline SET apikey=?, merchanid=? , acountdid=?, referenciapago=?, descripcionpago=?,
                                    moneda=?, responseurl=?, confirmationurl=?, bancoempresa=?,urlenvio=?, modooperacion =?,regn=0,nit=?
                            WHERE nit=?" ;
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("ssssssssssiss",$apikey, $merchanid , $acountdid, $referenciapago, $descripcionpago,
                                    $moneda, $responseurl, $confirmationurl, $bancoempresa,$urlenvio, $modooperacion,$nit,$nit);   
        }else if($accion==2){                           
            $this->query = "INSERT INTO configuracionpagosonline SET apikey=?, merchanid=? , acountdid=?, referenciapago=?, descripcionpago=?,
                                    moneda=?, responseurl=?, confirmationurl=?, bancoempresa=?,urlenvio=?, modooperacion =?,regn=0,nit=?" ;
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("ssssssssssis",$apikey, $merchanid , $acountdid, $referenciapago, $descripcionpago,
                                    $moneda, $responseurl, $confirmationurl, $bancoempresa,$urlenvio, $modooperacion,$nit);             
        }
        
        
        $this->preparar->execute();
        if($this->preparar->affected_rows != -1){
                echo '<div class="centrar">
                            <h3 class="titulo">Actualizacion con exito</h3>
                        </div> '; 
            }else{
                echo '<div class="centrar">
                        <h3 class="resaltaralerta">No se realizo la operacion,<br> Es posible que el articulo ya exista</h3>
                    </div>';
            } 
        $this->preparar->free_result();
        $this->conn->close();
            
        }
        
        public function getConfigPagos($nit=""){
            $this->db_open();
            $nit = $this->conn->real_escape_string($nit);
            $this->query=($nit != '')
                ?"SELECT * 
                FROM configuracionpagosonline 
                WHERE nit = '$nit' "

                :"SELECT * 
                FROM configuracionpagosonline";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            return $data;
            
        }
        /*public function __destruct(){
            unset($this);
        }*/
   
   
    }
?>