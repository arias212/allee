<?php
$contenido='
<h1>'.$_POST['nombre'].'Hemos recibido tu solicitud</h1>
';

$enviar=array(
'para'=>$_POST['email'],
'asunto'=>'Solicitud',
'cuerpomail'=>$contenido);

$mail_controler= new PhpmailerController();
$mail=$mail_controler->enviarEmail($enviar);
$infor=array(
    'nombre'=>$_POST['nombre'],
    'celular'=>$_POST['celular'],
    'email'=>$_POST['email'],
    'solicitud'=>$_POST['solicitud'],
    'respuesta'=>$mail
    );
$reporte_controller=new ArticulosController();
$reporte = $reporte_controller->setEmailTienda($infor);

?>