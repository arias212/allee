<?php 
require_once('../controllers/Autoload.php');
$Autoload=new Autoload();
$articulos_controller= new ArticulosController();
$articulos=$articulos_controller->queryBuscar($_POST['consulta']);
$html='';
        if(!empty($articulos)){
            for($i=0;$i < count($articulos);$i++){
                $html.='    
                <div class="infoEmpresa ">
                    <div class="letras centrar divTienda"  style="margin-left:15px;">
                        
                        
                         <img src="../app/public/img/usuarios/acelsoportes/fotos_articulos/'.$articulos[$i]['foto'].'" class="" id="" style="width:270px;height:270px;">
                        
                        <br><br>
                        <h1 class="resaltarcolor">'.strtoupper($articulos[$i]['descripcion']).'</h1><br>
                        <h1 class="titulo " style="font-size:2em;">Antes <del> $ '.number_format($articulos[$i]['pvpantes'],2).' </del></h1>
                        <h1 class="titulo" style="font-size:3em;">$ '.number_format($articulos[$i]['pventa'],2).'</h1><br>
                        <a href="https://api.whatsapp.com/send?text=https://fciempresas.com/tienda?id='.$articulos[$i]['codigo'].'" data-text="COMPARTIR EN WHATSAPP" data-action="share/whatsapp/share" class="miestilo" style="border: none; margin: 10px 0; font-size: 16px;">
                            <img border="0" src="./public/img/comwhatsapp.png" width="32px" height="32px" title="Comparte con tus contactos">
                        </a><br>
                        <div class="centrar trasitionf" style="border-radius:6px;box-shadow:0px 2px 5px 1px rgba(0,0,0,.2);color:#FFFFFF;background:#F32424;font-size:2em;width:180px;height:40px">
                            <a href="#" id="amodalventamm" class="amodalventamm" codigo="'.$articulos[$i]['codigo'].'" valor="'.$articulos[$i]['pventa'].'" style="color:#FFFFFF;"><i class="fa fa-credit-card-alt" aria-hidden="true" > Comprar</i></a>
                        </div><br>
                        <a href="https://wa.me/0573117061694/?text=Hola" data-text="COMPARTIR EN WHATSAPP" data-action="share/whatsapp/share" class="miestilo" style="border: none; margin: 10px 0; font-size: 16px;">
                                <img border="0" src="./public/img/logowhastapp.png" width="32px" height="32px" title="Chat con un experto Acel Soportes TV">
                            </a>
                        <a href="https://www.facebook.com/fcisoftware" data-text="COMPARTIR EN WHATSAPP" data-action="share/whatsapp/share" class="miestilo" style="border: none; margin: 10px 0; font-size: 16px;">
                            <img border="0" src="./public/img/logofacebook.png" width="32px" height="32px" title="Visita nuestro fanpage">
                        </a><br>
                        
                    </div> 
                    
                </div> <script>
                $(document).ready(function(){
                    $(".amodalventamm").click(function(e){
                        e.preventDefault();
                        //$("#modal").slideDown();
                        var valor = $(this).attr("valor");
                        var codigo = $(this).attr("codigo");
                        $("#carousel").slideUp();
                        
                        $.ajax({
                           url:"./views/pagar.php",
                           type:"POST",
                            dataType:"html",
                           async:true,
                           data:{codigo:codigo,valor:valor},
                           
                           success:function(response){
                                console.log(response);
                                $("#respuestas").html(response);
                                $("#respuestas").slideDown();
                           }, error: function(error){}
                        });
                    });
                });
                </script>';
            }
            
        }else{
            $html='<h1 class="titulo centrar">No existe información</h1>';
        }
    print($html);    
        ?>