<?php
    
    class VendedoresModel extends Model{

        
        public function set($vendedores_data = array()){
            
            foreach($vendedores_data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }  
            $nombre=strtoupper($nombre);
            $apellido=strtoupper($apellido);
            $direccion=strtoupper($direccion);
            $usuario=$_SESSION['acceso'];
            $this->query = "INSERT INTO vendedores SET nit=?,nombre= ?,apellido=?,direccion= ?,telefonos= ?,email= ?,observaciones= ?,usuario=?,
                            estado=1,eps=?,arl=?,cajacompen=?,inicontrato=?,fincontrato=?,tipocontrato=?,tipojornada=?,
                            vacaciones=?,salario=?,auxiliotrans=?,comisionventas=?,comisiongeneral=?,ccosto=?,caja=?,bodega=?,diasxmes=?,horasxjornada=?,
                            cuentanomina=?, banconomina=?,rodamiento=?"; 
            $this->db_open();
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("sssssssssssssisiddddsssiissd",$nit,$nombre,$apellido,$direccion,$telefonos,$email,$observaciones,$usuario,
                            $eps,$arl,$cajacompen,$inicontrato,$fincontrato,$tipocontrato,$tipojornada,$vacaciones,$salario,
                            $auxilio,$comisionventas,$comisiongeneral,$ccosto,$caja,$bodega,$diasxmes,$horasxjornada,$cuentanomina,$banconomina,$rodamiento);
            $this->preparar->execute();
            $this->origen="Vendedor";
            $this->actividad="Crear";
            $this->objeto=$nombre;
                if($this->preparar->affected_rows != -1){
                    echo '<div class="centrar">
                                <h3 class="titulo">Vendedor guardado con exito </h3>
                            </div> '; 
                }else{
                    echo '<div class="centrar">
                            <h3 class="resaltaralerta">No se realizo la operacion,<br> Es posible que el vendedor ya exista</h3>
                        </div>';
                }   
            $this->preparar->free_result();
            $this->conn->close();
        }
         
        public function get($vendedor = ''){
            $this->db_open();
            $vendedor = $this->conn->real_escape_string($vendedor);
            $this->query=($vendedor != '')
                ?"SELECT * 
                FROM vendedores 
                WHERE nit = '$vendedor'
                ORDER BY nombre"

                :"SELECT * 
                FROM vendedores 
                ORDER BY nombre";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            if(!empty($data)){
                return $data;
            }
            
            
        
        }
      
        public function del($nit=''){
            $this->db_open();
            $nit = $this->conn->real_escape_string($nit);
            $this->query = "DELETE FROM vendedores WHERE nit ='$nit'";
            $this->set_query();           
            
        }
        
        public function edit($vendedores_data = array()){
            
            foreach($vendedores_data as $key=>$value){
                $$key=$value;
            }     

            $usuario=$_SESSION['acceso'];
            $this->query = "UPDATE vendedores SET nombre= ?,apellido=?,direccion= ?,telefonos= ?,email= ?,observaciones= ?,usuario=?,
                            estado=?,eps=?,arl=?,cajacompen=?,inicontrato=?,fincontrato=?,tipocontrato=?,tipojornada=?,
                            vacaciones=?,salario=?,auxiliotrans=?,comisionventas=?,comisiongeneral=?,ccosto=?,caja=?,bodega=?,diasxmes=?,horasxjornada=?,
                            cuentanomina=?, banconomina=?,rodamiento=?
                            WHERE nit=?"; 
            $this->db_open();
            $nombre=strtoupper($nombre);
            $direccion=strtoupper($direccion);
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("ssssssssisssssisiddddsssiisds",$nombre,$apellido,$direccion,$telefonos,$email,$observaciones,$usuario,
                            $estado,$eps,$arl,$cajacompen,$inicontrato,$fincontrato,$tipocontrato,$tipojornada,$vacaciones,$salario,
                            $auxilio,$comisionventas,$comisiongeneral,$ccosto,$caja,$bodega,$diasxmes,$horasxjornada,$cuentanomina,$banconomina,$rodamiento,$nit);
            $this->preparar->execute();
            $this->origen="Vendedor";
            $this->actividad="Modificar";
            $this->objeto=$nombre;
                if($this->preparar->affected_rows != -1){
                    echo '<div class="centrar">
                                <h3 class="titulo">Vendedor guardado con exito </h3>
                            </div> '; 
                }else{
                    echo '<div class="centrar">
                            <h3 class="resaltaralerta">No se realizo la operacion,<br> Es posible que el vendedor ya exista</h3>
                        </div>';
                }   
            $this->preparar->free_result();
            $this->conn->close();

        }

        /*public function __destruct(){
            unset($this);
        }*/
   
   
    }
?>