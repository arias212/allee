<?php
    
    class OrdenestiendaModel extends Model{

        
        public function set($lineas_data = array()){
            
        }
         
        public function get($ordenestienda = ''){
            $this->db_open();
            $ordenestienda = $this->conn->real_escape_string($ordenestienda);
            $this->query=($ordenestienda != '')
                ?"SELECT a.regN AS regn , b.nit , b.nombre , b.telefonos, b.direccion , b.email1 , a.tipodoc , a.numdoc , a.ccosto,  a.tipodoc_afec , 
                        a.ccosto_afec , a.numdoc_afec , a.tipofac , a.descuento,  a.descuentop, a.fecha , a.fechav , a.puntov , a.valor , a.valorimp ,
                        a.vendedor , a.impresa , a.observaciones , a.pedido , a.ordencompra, a.condicionpago ,a.fechag ,a.anulada ,a.usuario ,b.reprelegal,
                        b.apellido, ord.estadoTx
                FROM ordenestienda AS a
                        LEFT JOIN nits AS b 
                        ON b.nit = a.nitcliente  
                        LEFT JOIN ordenestiendapagos AS ord
                        ON a.numdoc=ord.numdoc
                WHERE  a.numdoc = '$ordenestienda' AND a.tipodoc = '1'  
                ORDER BY fechag DESC"

                :"SELECT *
                FROM ordenestienda AS a 
                        LEFT JOIN nits AS b 
                        ON b.nit = a.nitcliente  
                        LEFT JOIN ordenestiendapagos AS ord
                        ON a.numdoc=ord.numdoc
                WHERE  tipodoc = '1' 
                ORDER BY fechag DESC";
                        
            $this->get_query();
            
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            if(!empty($data)){
                return $data;
            }
        
        }
        
        public function getE($ordenestienda = ''){
            $this->db_open();
            $ordenestienda = $this->conn->real_escape_string($ordenestienda);
            $this->query=($ordenestienda != '')
                ?"SELECT a.regN AS regn , b.nit , b.nombre , b.telefonos, b.direccion , b.email1 , a.tipodoc , a.numdoc , a.ccosto,  a.tipodoc_afec , 
                        a.ccosto_afec , a.numdoc_afec , a.tipofac , a.descuento,  a.descuentop, a.fecha , a.fechav , a.puntov , a.valor , a.valorimp ,
                        a.vendedor , a.impresa , a.observaciones , a.pedido , a.ordencompra, a.condicionpago ,a.fechag ,a.anulada ,a.usuario ,b.reprelegal,
                        b.apellido
                FROM ordenestienda AS a
                        LEFT JOIN nits AS b 
                        ON b.nit = a.nitcliente  
                WHERE  a.numdoc = '$ordenestienda' AND a.tipodoc = '1'  AND a.condicionpago='06' AND a.estado=''
                ORDER BY fechag DESC"

                :"SELECT *
                FROM ordenestienda AS a 
                        LEFT JOIN nits AS b ON b.nit = a.nitcliente  
                WHERE  tipodoc = '1' AND a.condicionpago='06' AND a.estado=''
                ORDER BY fechag DESC";
                        
            $this->get_query();
            
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            if(!empty($data)){
                return $data;
            }
        
        }
        
        public function getEle($ordenestienda = ''){
            $this->db_open();
            $ordenestienda = $this->conn->real_escape_string($ordenestienda);
            $this->query=($ordenestienda != '')
                ?"SELECT a.regN AS regn , b.nit , b.nombre , b.telefonos, b.direccion , b.email1 , a.tipodoc , a.numdoc , a.ccosto,  a.tipodoc_afec , 
                        a.ccosto_afec , a.numdoc_afec , a.tipofac , a.descuento,  a.descuentop, a.fecha , a.fechav , a.puntov , a.valor , a.valorimp ,
                        a.vendedor , a.impresa , a.observaciones , a.pedido , a.ordencompra, a.condicionpago ,a.fechag ,a.anulada ,a.usuario ,b.reprelegal,
                        b.apellido
                FROM ordenestienda AS a
                        LEFT JOIN nits AS b 
                        ON b.nit = a.nitcliente
                        LEFT JOIN ordenestiendapagos AS ti
                        ON a.numdoc=ti.numdoc
                WHERE  a.numdoc = '$ordenestienda' AND a.tipodoc = '1'
                ORDER BY a.fechag DESC"

                :"SELECT a.regN AS regn , b.nit , b.nombre , b.telefonos, b.direccion , b.email1 , a.tipodoc , a.numdoc , a.ccosto,  a.tipodoc_afec , 
                        a.ccosto_afec , a.numdoc_afec , a.tipofac , a.descuento,  a.descuentop, a.fecha , a.fechav , a.puntov , a.valor , a.valorimp ,
                        a.vendedor , a.impresa , a.observaciones , a.pedido , a.ordencompra, a.condicionpago ,a.fechag ,a.anulada ,a.usuario ,b.reprelegal,
                        b.apellido,ti.numdoc AS numdocor,ti.transactionState AS transactionState, ti.referenceCode AS referenceCode, ti.numfac AS numfac,
                        ti.estadoTx, a.caja
                FROM ordenestienda AS a 
                        LEFT JOIN nits AS b 
                        ON b.nit = a.nitcliente  
                        LEFT JOIN ordenestiendapagos AS ti
                        ON a.numdoc=ti.numdoc
                WHERE  a.tipodoc = '1'
                ORDER BY a.fechag DESC
                LIMIT 0,20";
                        
            $this->get_query();
            
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            if(!empty($data)){
                return $data;
            }
        
        }
        
        public function queryBuscar($ordenestienda = ''){
            $this->db_open();
            $ordenestienda = $this->conn->real_escape_string($ordenestienda);
            $this->query=($ordenestienda != '')
                ?"SELECT a.regN AS regn , b.nit , b.nombre , b.telefonos, b.direccion , b.email1 , a.tipodoc , a.numdoc , a.ccosto,  a.tipodoc_afec , 
                        a.ccosto_afec , a.numdoc_afec , a.tipofac , a.descuento,  a.descuentop, a.fecha , a.fechav , a.puntov , a.valor , a.valorimp ,
                        a.vendedor , a.impresa , a.observaciones , a.pedido , a.ordencompra, a.condicionpago ,a.fechag ,a.anulada ,a.usuario 
                FROM ordenestienda AS a
                        LEFT JOIN nits AS b ON b.nit = a.nitcliente  
                WHERE  b.nit = '$ordenestienda' AND a.tipodoc = '1'"

                :"SELECT *
                FROM ordenestienda AS a
                        LEFT JOIN nits AS b ON b.nit = a.nitcliente  
                WHERE  a.tipodoc = '1' 
                ORDER BY fechag DESC";
                        
            $this->get_query();
            
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            if(!empty($data)){
                return $data;
            }
            
            
        
        }
        public function del($regn=''){
            
        }
        public function edit($lineas_data = array()){
            
        }
        public function arqueoDia(){
            $this->query = "SELECT fecha, SUM(valor)  AS valor, SUM(valorimp) AS valorimp
            FROM ordenestienda 
            WHERE tipodoc='1' AND fecha BETWEEN  '2019-01-01' AND '2019-10-01' ";
            $this->get_query(); 
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            return $data;
            
        }
        //Consulta ultima factura a credito
        public function ultfac(){
            $this->query = "SELECT MAX(numdoc+1)  AS ultima_factura
            FROM ordenestienda 
            WHERE tipodoc=1 ";
            $this->get_query(); 
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            return $data;
            
        }
        //Consulta ultima factura a credito
        public function ultfacCD(){
            $this->query = "SELECT MAX(numdoc+1)  AS ultima_factura
            FROM ordenestienda 
            WHERE tipodoc=1 ";
            $this->get_query(); 
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            return $data;
            
        }
        
        public function datos($nit = ''){
            $this->db_open();
            $nit = $this->conn->real_escape_string($nit);
            $this->query=($nit != '')
                ?"SELECT SUM(a.valor) AS ventas 
                FROM ordenestienda AS pfa
                        LEFT JOIN nits AS nit ON b.nit = a.nitcliente  
                WHERE  b.regn='$nit' AND a.tipodoc = '1'"

                :"SELECT * 
                FROM a.regN as regn , b.nit , b.nombre ,b.telefonos,b.direccion,b.email1, a.tipodoc ,a.numdoc ,a.prefijo , a.caja ,
                        a.fecha , a.puntov ,a.valor , a.vlref ,a.vlrch ,a.vlrtd ,a.vlrcg ,a.vlrpt ,a.vendedor ,a.impresa ,a.observaciones ,
                        a.condicionpago , a.pormayor ,a.fechag ,a.anulada ,a.usuario
                        LEFT JOIN nits AS nit ON b.nit = pfac.nitcliente  
                WHERE  tipodoc = '1' 
                ORDER BY numdoc";
                        
            $this->get_query();
            
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            return $data;
        
        }
        
        public function setCabecera($data = array()){          
            foreach($data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }  
        
            $caja=$_SESSION['caja'];
            $cajero=$_SESSION['acceso'];
            
            $ultfac=$this->ultfacCD();
            $ultfactura=$ultfacCD[0]['ultima_factura'];
            
            $fecha= date("Y-m-d"); 
            if(empty($nit)){$nit="*";}
            if(empty($puntov)){$puntov="";}
            if(empty($vendedor)){$vendedor="";}
            
            $respuesta=$this->totalesDocumento();
            $totalfacpp=0;
            $totaldescuentov=0;
            $subtotal=0;
            $totaliva=0;
            if(!empty($respuesta)){   
                 for($n=1;$n < count ($respuesta);$n++){
                     $totalfacpp+= $respuesta[$n]['vlrtotal'];
                     $totaldescuentov+=$respuesta[$n]['descuentov'];
                     $subtotal+=$respuesta[$n]['subtotal'];
                     $totaliva+=$respuesta[$n]['ivav']; 
                 }
                 
            }
            $this->query = "INSERT INTO ordenestienda SET regN=0, tipodoc=1, numdoc=?, caja=?, fecha=?, nitcliente=?, puntov=?,
                                vlref=?, vldescuento=?, vliva=?, subtotal=?, valor=?,vendedor=?, 
                                impresa='S' , observaciones=?, usuario= ?, control= MD5(?) "; 
          
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("issssdddddssss",$ultfactura,$caja,$fecha,$nit,$puntov,$efectivo,$totaldescuentov,$totaliva,$subtotal,
                                        $totalfacpp,$vendedor,$observaciones,$cajero,$cajero);
            $this->preparar->execute();
            $this->origen="ordenestienda";                    
            $this->actividad="Fencabezado";
            $this->objeto=$ultfac;
            if($this->preparar->affected_rows != -1){
                    echo "cabecera";
            }else{
            }
            $this->delConTem();
            $this->xmlUltfac($ultfactura);
            
        }
//Totales documento facturati
        public function totalesDocumento(){
            $tipodoc = "facturati";
            $usuario = $_SESSION['acceso'];
            $this->query="SELECT  sum(vlrunidad) as vlrunidad, sum(descuentov) descuentov, sum(ivav) ivav, sum(vlrtotal) as vlrtotal,sum(vlrtotal)-sum(ivav) as subtotal
                WHERE  tipodoc = '$tipodoc' AND token_user=MD5('$usuario')";
                
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(empty($data)){
                $data='';
            }
            return $data;
        }
//Consulta contenido temporal facturati consultar
        public function contenidoTemporal($usuario,$tipodoc){
            
            $usuario=htmlentities(addslashes($usuario));
            $tipodoc=htmlentities(addslashes($tipodoc));
            
            $this->query="SELECT tem.regN as temregn, tem.tipodoc, tem.ccosto, tem.numdoc, art.codigo, art.regn, art.descripcion, avg(art.pventa) as pventa, sum(tem.cant) as cant,
                        sum(tem.cantd) as cantd, avg(tem.vlrunidad) as vlrunidad, art.iva as iva, avg(tem.descuentov) as descuentov , tem.descuento , tem.fechag, 
                        tem.token_user, tem.ivav, tem.usuario, tem.baseuni as baseuni, sum(tem.vlrtotal) as vlrtotal, avg(tem.pventam) pventam,
                        sum(tem.subuni) as subuni, tem.impoconsumo, tem.impoconsumov,tem.idrubro
                FROM detalle_documento AS tem 
                    LEFT JOIN articulos AS art ON art.codigo = tem.rubro  
                WHERE  tem.tipodoc = '$tipodoc' AND tem.token_user=MD5('$usuario') 
                GROUP BY tem.rubro , tem.descuento , tem.vlrunidad
                ORDER BY art.descripcion ASC";
            $this->get_query();
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        //Consulta contenido temporal facturati guardar
        public function consultaContenidoTemporal($usuario,$tipodoc){
             $usuario=$_SESSION['acceso'];
            
            $this->query="SELECT tem.regN as temregn, tem.tipodoc, tem.ccosto, tem.numdoc, art.codigo as rubro, art.regn, art.descripcion, avg(art.pventa) as pventa, sum(tem.cant) as cant,
                        sum(tem.cantd) as cantd, sum(tem.vlrunidad) as vlrunidad, art.iva as iva, avg(tem.descuento) as descuento , avg(tem.descuentov) descuentov, tem.fechag, 
                        tem.token_user, avg(tem.ivav) ivav, tem.usuario, avg(tem.baseuni) as baseuni, sum(tem.vlrtotal) as vlrtotal,tem.impoconsumo, avg(tem.impoconsumov) AS impoconsumov, art.cdimpo AS cdimp
                FROM detalle_documento AS tem
                    LEFT JOIN articulos AS art ON art.codigo = tem.rubro  
                WHERE  tem.tipodoc = '$tipodoc' AND tem.token_user=MD5('$usuario') 
                GROUP BY art.codigo, tem.descuento
                ORDER BY tem.vlrunidad";
            $this->get_queryDocu();
            foreach($this->documentos as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
            
        }
//Eliminar temporales detalle documento facturati
        public function eliminarTemporal($accion,$codigo,$tipodoc,$usuario,$descuento){
            $this->db_open();
            $accion = $this->conn->real_escape_string($accion);
            $tipodoc = $this->conn->real_escape_string($tipodoc);
            $codigo = $this->conn->real_escape_string($codigo);
            $descuento = $this->conn->real_escape_string($descuento);
            $usuario=$_SESSION['acceso'];
            
            $this->query = "DELETE FROM detalle_documento 
                            WHERE idrubro='$codigo' AND tipodoc='$tipodoc' AND token_user=MD5('$usuario') AND descuento='$descuento'";
            
            $this->origen="contenidodocumento";
            $this->actividad="Eliminar contenido";
            $this->objeto=$codigo;
            $this->set_query();
            
        }
        
        public function consultaTraslado(){
            $usuario=$_SESSION['acceso'];
            $tipodoc="facturati";
            $this->query="SELECT *
                FROM detalle_documento 
                WHERE  tipodoc = '$tipodoc' AND token_user=MD5('$usuario') 
                GROUP BY rubro, descuento";
                
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
        }
        
        public function getContenido($facpp = ''){
            $this->db_open();
            $facpp = $this->conn->real_escape_string($facpp);
            $this->query="SELECT pfac.regN AS regn, pfac.tipodoc, pfac.ccosto, pfac.numdoc ,pfac.rubro , pfac.cant , pfac.cantd, pfac.vlrunidad, pfac.iva, pfac.ivav as ivav,
                                pfac.descuento, pfac.descuentov, pfac.fechag, art.descripcion as descripcion, art.iva, art.pventa as pventa, pfac.baseuni, pfac.vlrtotal            
                            FROM ordenestiendac AS pfac 
                                LEFT JOIN articulos AS art 
                                ON art.codigo = pfac.rubro  
                            WHERE  pfac.tipodoc = '1' AND pfac.numdoc='$facpp'";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            return $data;
        }
//facturati
        public function delConTem($usuario,$tipodoc){
            $this->db_open();
            $usuario = $this->conn->real_escape_string($usuario);
            $tipodoc = $this->conn->real_escape_string($tipodoc);
            $this->query = "DELETE FROM detalle_documento WHERE token_user = MD5('$usuario') AND tipodoc='$tipodoc'";
            $this->set_query();           
            
        }
        //facturati
        public function pendiente(){
            $usuario=$_SESSION['acceso'];
            $this->query = "UPDATE detalle_documento 
            SET tipodoc='pendientecd'
            WHERE token_user = MD5('$usuario') AND tipodoc='facturati'";
            $this->set_query();           
            
        }
        public function udpOrdenestienda($data = array()){
            foreach($data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            } 
            $this->query = "UPDATE ordenestienda  SET numfac=?,usuario=?
                            WHERE numdoc = ?";
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("sss",$numfac,$usuario,$numdoc);
            $this->preparar->execute();      
            
        }
        
        public function udpOrdenestiendaPagos($data = array()){
            foreach($data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            } 
            $usuario=$_SESSION['acceso'];
            $this->query = "UPDATE ordenestiendapagos  SET numfac=?,usuario=?
                            WHERE numdoc = ?";
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("sss",$numfac,$usuario,$numdoc);
            $this->preparar->execute();         
            
        }
//facturati
        public function articulosPendientes(){
            $usuario=$_SESSION['acceso'];;
            $tipodoc="pendientecd";
            $this->query="SELECT tem.regN as temregn, tem.tipodoc, tem.ccosto, tem.numdoc, art.codigo, art.regn, art.descripcion, avg(art.pventa) as pventa, sum(tem.cant) as cant,
                        sum(tem.cantd) as cantd, sum(tem.vlrunidad) as vlrunidad, art.iva as iva, avg(tem.descuento) as descuento , sum(tem.descuentov) descuentov, tem.fechag, 
                        tem.token_user, sum(tem.ivav) ivav, tem.usuario, avg(tem.baseuni) as baseuni, sum(tem.vlrtotal) as vlrtotal
                FROM detalle_documento AS tem 
                    LEFT JOIN articulos AS art ON art.codigo = tem.rubro  
                WHERE  tem.tipodoc = '$tipodoc' AND tem.token_user=MD5('$usuario')
                GROUP BY art.codigo, tem.descuento
                ORDER BY art.descripcion";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
            
        }
        //facturati
        public function actualizaPendientes(){
            $usuario=$_SESSION['acceso'];
            $this->query = "UPDATE detalle_documento 
            SET tipodoc='facturati'
            WHERE token_user = MD5('$usuario') AND tipodoc='pendientecd'";
            $this->set_query();           
            
        }
       
        public function getEmpresa($empresa = ''){
            $this->db_open();
            $empresa = $this->conn->real_escape_string($empresa);
            $this->query=($empresa != '')
                ?"SELECT * 
                  FROM empresas 
                  WHERE empresa LIKE '%$empresa%' OR nit='$empresa'  
                  ORDER BY empresa"
                :"SELECT * FROM empresas ORDER BY empresa";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            

            return $data;
        
        }
//------------------------Contenido temporal tabla detalle documento------------------------------------------------------        
        public function setcontenido($data = array()){
            foreach($data as $key=>$value){
                $$key=$value;
            }
            $usuario=$_SESSION['acceso'];
            $idemp=$_SESSION['idemp'];
            $bodega=$_SESSION['bodega'];    
            $iva;
            $impoconsumo;
            $cantidad;
            $descuento=($descuento=='')?0:$descuento;
            $pventa;
            
                $this->query = "INSERT INTO detalle_documento SET regN='0', tipodoc='facturati', ccosto='', rubro=?, idrubro=?, 
                                cant=?, pventam=?, vlrunidad=?, baseuni=?,subuni=?, vlrtotal=?, iva=?, ivav=?,impoconsumo=?,impoconsumov=?,
                                descuento=?,descuentov=?, usuario=?, token_user=MD5(?), sugerido='', bodega=?";
            
                $this->db_open();
                $usuario=$_SESSION['acceso'];  
                $this->preparar=$this->conn->prepare($this->query);
                $this->preparar->bind_param("ssddddddidididsss",$codigo,$regn,$cantidad,$pventam,$pventa,$baseuni,$subuni,$totaluni,
                                                $iva,$ivav,$impoconsumo,$impoconsumov,$descuento,$descuentov,$usuario,$usuario,$bodega);
                $this->preparar->execute();
                $this->origen="compra";                    
                $this->actividad="Fencabezado";
                if($this->preparar->affected_rows != -1){
                    echo '<div class="centrar">
                                <h3 class="titulo"> </h3>
                            </div> '; 
                }else{
                    echo '<div class="centrar">
                            <h3 class="resaltaralerta">No se realizo la operacion</h3>
                        </div>';
                }   
            $this->preparar->free_result();
            $this->conn->close();
        }
        
        public function updContenido($data = array()){
            foreach($data as $key=>$value){
                $$key=$value;
            }
            if(empty($usuario)){
                $usuario=$_SESSION['acceso'];
            }
            $bodega=$_SESSION['bodega'];
            $subuni=$baseuni*$cant;
            $descuentov=($baseuni*($descuento/100));
            $ivav=(($baseuni-$descuentov)*($iva/100));
            $impov=(($baseuni-$descuentov)*($impo/100));
            $vlrtotal=(($baseuni-$descuentov)+($ivav+$impov))*$cant;
            
                $this->query = "INSERT INTO detalle_documento SET cant=?,vlrunidad=?,baseuni=?, subuni=?, vlrtotal=?, ivav=?,impoconsumov=?, descuentov=?,
                                descuento=?,iva=?,impoconsumo=?,rubro=?,idrubro=?,pventam=?,token_user=MD5(?),usuario=?,tipodoc=?";
            
                $this->db_open();
                $this->preparar=$this->conn->prepare($this->query);
                $this->preparar->bind_param("ddddddddiiisidsss",$cant,$vlrunidad,$baseuni,$subuni,$vlrtotal,$ivav,$impov,$descuentov,$descuento,
                                            $iva,$impo,$codigo,$idrubro,$pventam,$cajero,$cajero,$tipodoc);
                $this->preparar->execute();
                $this->origen="compra";                    
                $this->actividad="Fencabezado";
                if($this->preparar->affected_rows != -1){
                    echo '<div class="centrar">
                                <h3 class="titulo"> </h3>
                            </div> '; 
                }else{
                    echo '<div class="centrar">
                            <h3 class="resaltaralerta">No se realizo la operacion</h3>
                        </div>';
                }   
            $this->preparar->free_result();
            $this->conn->close();
        }
        
     
//------------------------------consultas    
        public function facturaNit($ordenestienda = ''){
            $this->db_open();
            $ordenestienda = $this->conn->real_escape_string($ordenestienda);
            $this->query="SELECT a.regN AS regn , b.nit , b.nombre , b.telefonos, b.direccion , b.email1 , a.tipodoc , a.numdoc , a.ccosto,  a.tipodoc_afec , 
                        a.ccosto_afec , a.numdoc_afec , a.tipofac , a.descuento,  a.descuentop, a.fecha , a.fechav , a.puntov , a.valor , a.valorimp ,
                        a.vendedor , a.impresa , a.observaciones , a.pedido , a.ordencompra, a.condicionpago ,a.fechag ,a.anulada ,a.usuario ,b.reprelegal,
                        b.apellido,ti.numdoc AS numdocor,ti.transactionState AS transactionState, ti.referenceCode AS referenceCode, ti.numfac AS numfac,
                        ti.estadoTx, a.caja
                        FROM ordenestienda AS a
                        LEFT JOIN nits AS b 
                        ON b.nit = a.nitcliente 
                        LEFT JOIN ordenestiendapagos AS ti
                        ON a.numdoc=ti.numdoc
                WHERE  b.nit = '$ordenestienda' 
                ORDER BY a.fechag DESC";
                        
            $this->get_query();
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        
        }
        public function facturaNumdoc($ordenestienda = ''){
            $this->db_open();
            $ordenestienda = $this->conn->real_escape_string($ordenestienda);
            $this->query="SELECT a.regN AS regn , b.nit , b.nombre , b.telefonos, b.direccion , b.email1 , a.tipodoc , a.numdoc , a.ccosto,  a.tipodoc_afec , 
                        a.ccosto_afec , a.numdoc_afec , a.tipofac , a.descuento,  a.descuentop, a.fecha , a.fechav , a.puntov , a.valor , a.valorimp ,
                        a.vendedor , a.impresa , a.observaciones , a.pedido , a.ordencompra, a.condicionpago ,a.fechag ,a.anulada ,a.usuario ,b.reprelegal,
                        b.apellido,ti.numdoc AS numdocor,ti.transactionState AS transactionState, ti.referenceCode AS referenceCode, ti.numfac AS numfac,
                        ti.estadoTx, a.caja
                FROM ordenestienda AS a
                        LEFT JOIN nits AS b 
                        ON b.nit = a.nitcliente 
                        LEFT JOIN ordenestiendapagos AS ti
                        ON a.numdoc=ti.numdoc
                WHERE  a.numdoc = '$ordenestienda'";
                        
            $this->get_query();
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        
        }
        public function facturaCaja($ordenestienda = ''){
            $this->db_open();
            $ordenestienda = $this->conn->real_escape_string($ordenestienda);
            $this->query="SELECT a.regN AS regn , b.nit , b.nombre , b.telefonos, b.direccion , b.email1 , a.tipodoc , a.numdoc , a.ccosto,  a.tipodoc_afec , 
                        a.ccosto_afec , a.numdoc_afec , a.tipofac , a.descuento,  a.descuentop, a.fecha , a.fechav , a.puntov , a.valor , a.valorimp ,
                        a.vendedor , a.impresa , a.observaciones , a.pedido , a.ordencompra, a.condicionpago ,a.fechag ,a.anulada ,a.usuario ,b.reprelegal,
                        b.apellido,ti.numdoc AS numdocor,ti.transactionState AS transactionState, ti.referenceCode AS referenceCode, ti.numfac AS numfac,
                        ti.estadoTx, a.caja
                FROM ordenestienda AS a
                        LEFT JOIN nits AS b 
                        ON b.nit = a.nitcliente  
                        LEFT JOIN ordenestiendapagos AS ti
                        ON a.numdoc=ti.numdoc
                WHERE  a.caja = '$ordenestienda' 
                ORDER BY fechag DESC";
                        
            $this->get_query();
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        
        }
        public function getBodegaFecha($facturapp,$ini,$fin){
            $this->db_open();
            $facturapp = $this->conn->real_escape_string($facturapp);
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query=($facturapp!='')?"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav         
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND a.bodega ='$facturapp' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag"
                            :"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function getCajaFecha($facturapp,$ini,$fin){
            $this->db_open();
            $facturapp = $this->conn->real_escape_string($facturapp);
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query=($facturapp!='')?"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.caja ='$facturapp' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag"
                            :"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function getCodigoFecha($codigo,$ini,$fin){
            $this->db_open();
            $codigo = $this->conn->real_escape_string($codigo);
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query=($codigo!='')?"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND a.rubro ='$codigo' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag"
                            :"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function getNitFecha($nit,$ini,$fin){
            $this->db_open();
            $nit = $this->conn->real_escape_string($nit);
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query=($nit!='')?"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav        
                                FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.nitcliente ='$nit' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag"
                            
                            :"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav        
                                FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function getVendedorFecha($vendedor,$ini,$fin){
            $this->db_open();
            $vendedor = $this->conn->real_escape_string($vendedor);
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query=($vendedor!='')?"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav        
                                FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.vendedor ='$vendedor' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag"
                            
                            :"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav        
                                FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function getFecha($ini,$fin){
            $this->db_open();
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query="SELECT a.tipodoc, a. BH ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function getGrupoFecha($grupo,$ini,$fin){
            $this->db_open();
            $grupo = $this->conn->real_escape_string($grupo);
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query=($grupo!='')?"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND b.grupo ='$grupo' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag"
                            :"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function getLineaFecha($linea,$ini,$fin){
            $this->db_open();
            $linea = $this->conn->real_escape_string($linea);
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query=($linea!='')?"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND b.linea ='$linea' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag"
                            :"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function getCiudadFecha($ciudad,$ini,$fin){
            $this->db_open();
            $ciudad = $this->conn->real_escape_string($ciudad);
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query=($ciudad!='')?"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND e.ciudad ='$ciudad' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag"
                            :"SELECT a.tipodoc, a.numdoc ,a.ccosto ,a.fechag ,d.nitcliente , e.nombre, e.direccion, e.email1, d.vendedor,
                                        d.caja, a.rubro , b.descripcion, b.grupo , b.linea , e.ciudad , a.cant, a.cantd, a.vlrunidad , a.baseuni,
                                        a.vlrtotal, a.descuento, a.descuentov, a.impoconsumo , a.impoconsumov , a.iva , a.ivav          
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN ordenestienda AS d
                                ON d.numdoc = a.numdoc
                                LEFT JOIN nits AS e
                                ON d.nitcliente = e.nit
                            WHERE  a.tipodoc = '1' AND d.fecha BETWEEN '$ini' AND '$fin' 
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function facturaFecha($ini,$fin){
            $this->db_open();
            $ini = $this->conn->real_escape_string($ini);
            $fin = $this->conn->real_escape_string($fin);
            $this->query="  SELECT a.regN AS regn , b.nit , b.nombre , b.telefonos, b.direccion , b.email1 , a.tipodoc , a.numdoc , a.ccosto,  a.tipodoc_afec , 
                        a.ccosto_afec , a.numdoc_afec , a.tipofac , a.descuento,  a.descuentop, a.fecha , a.fechav , a.puntov , a.valor , a.valorimp ,
                        a.vendedor , a.impresa , a.observaciones , a.pedido , a.ordencompra, a.condicionpago ,a.fechag ,a.anulada ,a.usuario ,b.reprelegal,
                        b.apellido,ti.numdoc AS numdocor,ti.transactionState AS transactionState, ti.referenceCode AS referenceCode, ti.numfac AS numfac,
                        ti.estadoTx, a.caja
                            FROM ordenestienda AS a
                            LEFT JOIN nits AS b
                            ON a.nitcliente = b.nit
                            LEFT JOIN ordenestiendapagos AS ti
                            ON a.numdoc=ti.numdoc
                            WHERE a.fechag BETWEEN '$ini' AND '$fin' ";
            
            $this->get_query();
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            if(!empty($data)){
                return $data;
            }
        
        }
        public function getCodigo($facpp = ''){
            $this->db_open();
            $facpp = $this->conn->real_escape_string($facpp);
            $this->query="SELECT *         
                            FROM ordenestiendac AS a 
                            LEFT JOIN ordenestienda AS f
                                ON f.numdoc = a.numdoc  
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                            WHERE  a.tipodoc = '1' AND a.rubro='$facpp'
                            ORDER BY a.fechag DESC";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        public function getBodega($facpp = ''){
            $this->db_open();
            $facpp = $this->conn->real_escape_string($facpp);
            $this->query="SELECT *       
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b ON b.codigo = a.rubro  
                            WHERE  a.tipodoc = '1' AND a.bodega LIKE'%$facpp%'
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        
        public function getTpago($facpp = ''){
            $this->db_open();
            $facpp = $this->conn->real_escape_string($facpp);
            $this->query="SELECT *       
                            FROM ordenestienda AS a 
                                LEFT JOIN nits AS b 
                                ON a.nitcliente = b.nit  
                            WHERE  a.tipodoc = '1' AND a.condicionpago ='$facpp'
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }
        
        public function getPendientePago($ordenestienda = ''){
            $this->db_open();
            $ordenestienda = $this->conn->real_escape_string($ordenestienda);
            $this->query=(empty($ordenestienda))?"SELECT *
                FROM ordenestienda AS a 
                LEFT JOIN nits AS b 
                ON b.nit = a.nitcliente  
                WHERE  a.tipodoc = '1' AND a.condicionpago = '06'  
                ORDER BY a.fechav DESC"
                :"SELECT *
                FROM ordenestienda AS a 
                LEFT JOIN nits AS b 
                ON b.nit = a.nitcliente  
                WHERE  a.tipodoc = '1' AND a.condicionpago = '06' AND a.nitcliente='$ordenestienda'
                ORDER BY a.fechav DESC";
                        
            $this->get_query();
            
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            if(!empty($data)){
                return $data;
            }
        
        }
//contenido factura cabecera
        public function getContenidoNumdoc($facpp = ''){
            $this->db_open();
            $facpp = $this->conn->real_escape_string($facpp);
            $this->query="SELECT a.regN AS regn, a.tipodoc, a.ccosto, a.numdoc ,a.rubro , a.cant , a.cantd, a.vlrunidad, a.baseuni,  a.vlrtotal,a.iva, a.ivav, 
                                a.descuento, a.descuentov, a.fechag, b.descripcion, b.referencia, b.iva as ivaart, a.bodega, a.impoconsumo, a.impoconsumov,t.descripcion1 AS des   
                            FROM ordenestiendac AS a 
                                LEFT JOIN articulos AS b 
                                ON b.codigo = a.rubro  
                                LEFT JOIN tablas AS t
                                ON b.unidad = t.codigo
                            WHERE  a.tipodoc = '1' AND a.numdoc ='$facpp' 
                            GROUP BY a.rubro, a.descuento
                            ORDER BY a.fechag";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        }    
//Traslado de tabla temporal_documento a ordenestiendac
    public function trasladoContenido($numdoc,$usuario,$tipodoc){
        $this->db_open();
        $numdoc = $this->conn->real_escape_string($numdoc);
        $tipodoc = $this->conn->real_escape_string($tipodoc);
        $usuario=$_SESSION['acceso']; 
            $variables=$this->consultaContenidoTemporal($usuario,$tipodoc);
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($variables)){
                    for($n=0;$n < count($variables);$n++){
                        $cdimp      =$variables[$n]['cdimp'];
                        $rubro      =$variables[$n]['rubro'];
                        $cant       =$variables[$n]['cant'];
                        $vlrunidad  =$variables[$n]['vlrunidad'];
                        $baseuni    =$variables[$n]['baseuni'];
                        $vlrtotal   =$variables[$n]['vlrtotal'];
                        $descuento  =$variables[$n]['descuento'];
                        $descuentov =$variables[$n]['descuentov'];
                        $iva        =$variables[$n]['iva'];
                        $ivav       =$variables[$n]['ivav'];
                        $impo       =$variables[$n]['impoconsumo'];
                        $impov      =$variables[$n]['impoconsumov'];
                        $bodega     =$_SESSION['bodega'];
                        $usuario=$_SESSION['acceso']; 
                        $this->query = "INSERT INTO ordenestiendac SET regN='0',tipodoc=1,numdoc=?, rubro=?, cant=?,vlrunidad=?, 
                                                    baseuni=?,vlrtotal=?,descuento=?,descuentov=?, usuario=?,iva=?, token_user=MD5(?), ivav=?, bodega=?
                                                    , impoconsumo=?,impoconsumov=?,cdimp=?"; 
                        $this->db_open();  
                        $this->preparar=$this->conn->prepare($this->query);
                        $this->preparar->bind_param("isddddidsisdsdds",$numdoc,$rubro,$cant,$vlrunidad,$baseuni,$vlrtotal,$descuento,$descuentov,$usuario,
                                                    $iva,$usuario,$ivav,$bodega,$impo,$impov,$cdimp);
                        $this->preparar->execute();
                        $this->origen="contenidodocumento";
                        $this->actividad="Crear contenido";
                        $this->objeto=$rubro;
                            if($this->preparar->affected_rows != -1){
                                
                            }else{
                                
                            }   
                    }
            }
            $this->origen="contenidodocumento";
            
        }
        
        public function detalleTiendaOnline($codigo,$numdoc){
        $this->db_open();
        $codigo = $this->conn->real_escape_string($codigo);
        $numdoc = $this->conn->real_escape_string($numdoc);
        $articulos_controller= new ArticulosController();
        $articulo=$articulos_controller->buscarCodigo($_POST['codigo']);
        $pventa=$articulo[0]['pventa'];
        $baseuni=$articulo[0]['pventa']/(1+(($pventa=$articulo[0]['iva']+$pventa=$articulo[0]['impoconsumo'])/100));
        $descuentov=$baseuni*($pventa=$articulo[0]['descuento']/100);
        $ivav=($baseuni-$descuentov)*($pventa=$articulo[0]['iva']/100);
        $impv=($baseuni-$descuentov)*($pventa=$articulo[0]['impoconsumo']/100);
        
            if(!empty($articulo)){
                for($n=0;$n < count($articulo);$n++){
                    $cdimp      =$articulo[$n]['cdimpo'];
                    $rubro      =$articulo[$n]['codigo'];
                    $cant       =1;
                    $vlrunidad  =$articulo[$n]['pventa'];
                    $baseuni    =$baseuni;
                    $vlrtotal   =$articulo[$n]['pventa'];
                    $descuento  =$articulo[$n]['descuento'];
                    $descuentov =$descuentov;
                    $iva        =$articulo[$n]['iva'];
                    $ivav       =$ivav;
                    $impo       =$articulo[$n]['impoconsumo'];
                    $impov      =$impv;
                    $bodega     ='';
                    $usuario=''; 
                    $this->query = "INSERT INTO ordenestiendac SET regN='0',tipodoc=1,numdoc=?, rubro=?, cant=?,vlrunidad=?, 
                                                baseuni=?,vlrtotal=?,descuento=?,descuentov=?, usuario=?,iva=?, token_user=MD5(?), ivav=?, bodega=?
                                                , impoconsumo=?,impoconsumov=?,cdimp=?"; 
                    $this->db_open();  
                    $this->preparar=$this->conn->prepare($this->query);
                    $this->preparar->bind_param("isddddidsisdsdds",$numdoc,$rubro,$cant,$vlrunidad,$baseuni,$vlrtotal,$descuento,$descuentov,$usuario,
                                                $iva,$usuario,$ivav,$bodega,$impo,$impov,$cdimp);
                    $this->preparar->execute();
                    $this->origen="contenidodocumento";
                    $this->actividad="Crear contenido";
                    $this->objeto=$rubro;
                        if($this->preparar->affected_rows != -1){
                            
                        }else{
                            
                        }   
                }
            }
            $this->origen="contenidodocumento";
            
        }
//Grabar ordenestienda ordenestiendamm
        public function setPFacturasTi($data = array()){
            foreach($data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }  
        
            $fecha= date("Y-m-d"); 
            if(empty($nit)){$nit="*";}
            if(empty($puntov)){$puntov="";}
            if(empty($vendedor)){$vendedor="";}
            
            
            $this->query = "INSERT INTO ordenestienda SET regN=0, tipodoc=1, numdoc=?, caja=?, fecha=?, nitcliente=?, puntov=?,
                                vlref=?, vldescuento=?, vliva=?, subtotal=?, valor=?,vendedor=?, 
                                impresa='S' , observaciones=?, usuario= ?, control= ?,vlimpoconsumo=?,condicionpago=?,fechav=?,numdoc_afec=? "; 
          
            $this->db_open();
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("issssdddddssssdsss",$numdoc,$caja,$fecha,$nit,$puntov,$efectivo,$totaldescuentov,$totaliva,$subtotal,
                                        $totalfacpp,$vendedor,$observaciones,$cajero,$numeroapro,$totalimpo,$tipopago,$fechav,$idpago);
            $this->preparar->execute();
            $this->origen="Facturapp";                    
            $this->actividad="Fencabezado";
            //$this->objeto=$ultfac;
            if($this->preparar->affected_rows != -1){
                
            }else{
                
            }
    }
//Actualiza stock        
        public function updateArticulo($usuario,$tipodoc){
            $this->db_open();
            $tipodoc = $this->conn->real_escape_string($tipodoc);
            $usuario = $this->conn->real_escape_string($usuario);
            $variables=$this->consultaContenidoTemporal($usuario,$tipodoc);
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            $bodega     =$_SESSION['bodega'];
            $usuario    =$_SESSION['acceso'];
            $caja       =$_SESSION['caja'];
            if(!empty($variables)){
                    for($n=0;$n < count($variables);$n++){
                        $rubro      =$variables[$n]['rubro'];
                        $cant       =$variables[$n]['cant'];
                        $vlrunidad  =$variables[$n]['pcosto'];
                        $vlrtotal   =$variables[$n]['vlrtotal'];
                        $descuento  =$variables[$n]['descuento'];
                        $descuentov =$variables[$n]['descuentov'];
                        $iva        =$variables[$n]['iva'];
                        $ivav       =$variables[$n]['ivav'];
                        $baseuni    =$variables[$n]['pcosto']-($variables[$n]['pcosto']*($variables[$n]['descuento']/100));
                        $subuni     =$baseuni*$cant;
                         
                        
                        
                        $this->query = "UPDATE articulos SET inv_cant = inv_cant - ?, usuario = ? 
                                        WHERE codigo = ?"; 
                        $this->db_open();  
                        $this->preparar=$this->conn->prepare($this->query);
                        $this->preparar->bind_param("dss",$cant,$usuario,$rubro);
                        $this->preparar->execute();
                        $this->origen="contenidodocumento";
                        $this->actividad="Crear contenido";
                        $this->objeto=$rubro;
                            if($this->preparar->affected_rows != -1){
                                 echo 'grabado';
                            }else{
                                echo  'error'; ;
                            }   
                    }
            }
            $this->origen="contenidodocumento";
            
        }
//Iva tercero        
        public function ivater($nit){
            $nit=htmlentities(addslashes($nit));
            $this->query="SELECT SUM(fac.vlrunidad) AS ventas, fac.iva, (fac.vlrunidad-fac.descuento)-(SUM(fac.vlrunidad)/(1+(iva/100))) AS valoriva,
                            SUM(fac.descuento) AS descuento, SUM(fac.vlrunidad)/(1+(iva/100))-fac.descuento AS base         
                            FROM ordenestiendac AS fac
                            LEFT JOIN ordenestienda AS nit ON nit.numdoc = fac.numdoc 
                            LEFT JOIN nits AS ter ON nit.nitcliente = ter.nit
                            WHERE  ter.regn ='$nit' AND nit.tipodoc = 1";
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            return $data;
        }
        
        public function setPagoRespuesta($data = array()){          
            foreach($data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }  
            $this->query = "INSERT INTO ordenestiendapagos SET Regn=0, ApiKey=?,merchant_id=?,referenceCode=?,TX_VALUE=?,
                            New_value=?,currency=?,transactionState=?,firmacadena=?,firmacreada=?,firma=?,reference_pol=?,cus=?,
                            extra1=?,pseBank=?,lapPaymentMethod=?,transactionId=?,estadoTx=?,numdoc=?"; 
          
            $this->db_open_tienda($idemp);
            //$usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("sssddssssssssdssss",$ApiKey,$merchant_id,$referenceCode,$TX_VALUE,$New_value,$currency,
                                        $transactionState,$firma_cadena,$firmacreada,$firma,$reference_pol,$cus,$extra1,
                                        $pseBank,$lapPaymentMethod,$transactionId,$estadoTx,$numdoc);
            $this->preparar->execute();
            $this->origen="ordenestienda";                    
            $this->actividad="Fencabezado";
            $this->objeto="";
            if($this->preparar->affected_rows != -1){
            }else{
            }
            
        }
        
        public function setPagoManual($data = array()){          
            foreach($data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }  
            $this->query = "INSERT INTO ordenestiendapagos SET Regn=0, TX_VALUE=?, New_value=?,transactionState=4,
                            estadoTx='Transacción rechazada',numdoc=?, observacion=?"; 
          
            $this->db_open();
            //$usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("ddss",$TX_VALUE,$TX_VALUE,$numdoc,$observacion);
            $this->preparar->execute();
            $this->origen="ordenestienda";                    
            $this->actividad="Fencabezado";
            $this->objeto="";
            if($this->preparar->affected_rows != -1){
                echo"grabado";
            }else{
            }
            
        }
        
        public function getPago($ordenestienda = ''){
            $this->db_open();
            $ordenestienda = $this->conn->real_escape_string($ordenestienda);
            $this->query="SELECT *
                FROM ordenestiendapagos
                WHERE  numdoc = '$ordenestienda'
                ORDER BY fechag DESC";
                        
            $this->get_query();
            
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            if(!empty($data)){
                return $data;
            }
        
        }
        /*public function __destruct(){
            unset($this);
        }*/
   
    }
?>