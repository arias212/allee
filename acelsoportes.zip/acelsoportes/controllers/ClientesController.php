<?php
    
    class ClientesController{
        private $model;
        private $envioemail;
        
        
        public function __construct(){
            $this->model=new ClientesModel();
        }
        
        public function set($clientes_data=array()){
            return  $this->model->set($clientes_data);
        }
        public function setRapido($clientes_data=array()){
            return  $this->model->setRapido($clientes_data);
        }
        public function get($cliente =''){
             return  $this->model->get($cliente);
        }
        public function getDep($cliente =''){
             return  $this->model->getDep($cliente);
        }
        public function del($cliente =''){
             return  $this->model->del($cliente);
        }
        public function edit($cliente_data=array()){
            return  $this->model->edit($cliente_data);
        }
        
        public function queryBuscar($cliente =''){
            return  $this->model->queryBuscar($cliente);
        }
        
        public function datos($cliente =''){
            return  $this->model->datos($cliente);
        }
        
        public function puntov($cliente =''){
            return  $this->model->puntov($cliente);
        }
        public function getNit($cliente =''){
             return  $this->model->getNit($cliente);
        }
        
        public function editInfo($cliente_data=array()){
            return  $this->model->editInfo($cliente_data);
        }
        
        public function editContac($cliente_data=array()){
            return  $this->model->editContac($cliente_data);
        }
        
        public function editVenta($cliente_data=array()){
            return  $this->model->editVenta($cliente_data);
        }
        
    }
?>
