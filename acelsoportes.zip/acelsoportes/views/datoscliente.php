<?php
    require_once('../controllers/Autoload.php');
    $Autoload=new Autoload();
    $cliente_controller = new ClientesController();
    $puntov_controller = new ClientesController(); 
    $nit=htmlentities(addslashes($_POST['nit']));
    $cliente = $cliente_controller->getNit($nit);
    $puntov = $puntov_controller->puntov($cliente[0]['nit']);
    $tdocumento_controller=new TdocumentoController();
    $tdocumento=$tdocumento_controller->get();
    $ciudad_controller=new CiudadesController();
    $ciudad=$ciudad_controller->getlista();
    
    $tdocumento_select='';
        for($n=0;$n< count($tdocumento);$n++){
            if (!empty($tdocumento)){
                $tdocumento_select.='<option value="'.$tdocumento[$n]['codigo'].'">'.$tdocumento[$n]['descripcion'].'</option>';
            }
        }
    
    $ciudad_select='';
        for($n=0;$n< count($ciudad);$n++){
            if (!empty($ciudad)){
                $ciudad_select.='<option value="'.$ciudad[$n]['codigo'].'">'.$ciudad[$n]['descripcion'].'</option>';
            }
        }
    
    $puntov_select='';
    if (!empty($puntov)){
        for($n=0;$n< count($puntov);$n++){
            $puntov_select.='<option value="'.$puntov[$n]['puntov'].'">'.$puntov[$n]['puntov'].'</option>';
        }
    }
    $vendedor_select='';
    if($cliente[0]['vendedor']==''){
        $vendedores_controller = new VendedoresController();
        $vendedores= $vendedores_controller->get();
        if (!empty($vendedores)){
            for($n=0;$n<count($vendedores);$n++){
                $vendedor_select.='<option value="'.$vendedores[$n]['nit'].'">'.$vendedores[$n]['nombre'].'</option>';
            }
        }
    }else{
        $vendedor_select.='<option value="'.$cliente[0]['vendedor'].'">'.$cliente[0]['vendedor'].'</option>';
    }
    
    if(!empty($cliente)){
    $template='
    
        <div name="datoscliente" id="datoscliente" >
            <label class="letras">DV: <span class="resaltarletras" id="nitcliente">'.$cliente[0]['dv'].'</span></label><br>
            <label class="letras">Nombres: <span class="resaltarletras">'.$cliente[0]['nombre'].'</span></label><br>
            <label class="letras">Apellidos: <span class="resaltarletras">'.$cliente[0]['apellido'].'</span></label><br>
            <label class="letras">Razon social: <span class="resaltarletras">'.$cliente[0]['reprelegal'].'</span></label><br>
            <select name="listavendedor" id="listavendedor" class="input">
                <option value="">Selecciona el vendedor</option>
                '.$vendedor_select.'
            </select><br>
            <label class="letras">e-mail: <span id= "email" class="resaltarletras">'.$cliente[0]['email1'].'</span></label><br>
            <select name="puntov" id="puntov" placeholder="Puntov" class="input">
                '.$puntov_select.'
            </select>
            
        </div>';
    }else{
        $template='
        <div style="" class="" >
            <div >
                <a href="#" id="anuevocliente"><img src="./public/img/nuevocliente.png" class="imgclientenuevo"><br>Nuevo tercero</a>
            </div>
        </div>   
        <div name="datoscliente" class="" id="datoscliente">
            <div class="centrar" style="display:none;" id="formucliente" >
                <span class="resaltarletras" id="nitcliente"></span>
                <div>
                    <label class="resaltarcolor">Tipo de documento:</label>
                    <select name="tdocumento" id="tdocumento" placeholder="Linea" class="input">
                        <option value="">Tipo documento</option>
                        '.$tdocumento_select.'
                    </select>
                </div>
                <div>
                    <label class="resaltarcolor">Tipo de persona:</label>
                    <select name="tpersona" id="tpersona" placeholder="Linea" class="input">
                        <option value="2">Persona Natural y asimiladas</option>
                        <option value="1">Persona Jurídica y asimiladas</option>
                    </select>
                </div>
                <div>
                    <label class="resaltarcolor">Regimen fiscal:</label>
                    <select name="rfiscal" id="rfiscal" placeholder="Linea" class="input">
                        <option value="48">Impuestos sobre la venta del IVA</option>
                        <option value="49">No responsables del IVA</option>
                    </select>
                </div>
                <input type="text" id="dv" name="dv" placeholder="Digito verificacion"  class="input">
                <input type="text" id="nuevonombre" name="nombre" placeholder="Nombres" class="input">
                <input type="text" id="nuevoapellido" name="apellido" placeholder="Apellidos" class="input">
                <input type="text" id="reprelegal" name="reprelegal" placeholder="Razon social" class="input">
                <input type="email" id="nuevoemail" name="email" placeholder="email" class="input" required>
                <input type="text" id="nuevotelefono" name="telefono" placeholder="Telefono" class="input">
                <input type="text" id="nuevodireccion" name="nuevodireccion" placeholder="Direccion" class="input">
                <input type="text" id="nuevopuntov" name="nuevopuntov" placeholder="Punto de venta"  class="input">
                <div>
                    <label class="resaltarcolor">Ciudad:</label>
                    <select name="ciudad" id="ciudad" placeholder="Linea" class="input">
                        <option value="">Ciudad</option>
                        '.$ciudad_select.'
                    </select>
                </div><br>
                <div class="centrar">
                    <a href="#" id="aocultar" ><img src="./public/img/ocultar.png" class="centrar imgherramientas"></a>
                    <a href="#" id="guardar" ><img src="./public/img/guardar.png" class="centrar imgherramientas"></a>
                </div>
            </div>
        </div>        
        
            <script>
            $(document).ready(function(){
            
                $("#anuevocliente").click(function(e){
                    e.preventDefault();
                    $("#formucliente").slideDown();
                    $("#ocultar").slideDown();
                    $("#guardar").slideDown();
                    $(this).slideUp();
                }); 
                
                $("#guardar").click(function(e){
                    e.preventDefault();
                    
                    if($("#nuevonit").val() !="" && $("#nuevonombre").val() !="" && $("#nuevotelefono").val() !="" && $("#nuevoemail").val() !=""){
                        var tdocumento = $("#tdocumento").val(); 
                        var nit = $("#buscarnit").val();
                        var dv = $("#dv").val();
                        var nombre = $("#nuevonombre").val();
                        var apellido = $("#nuevoapellido").val();
                        var telefono = $("#nuevotelefono").val();
                        var email = $("#nuevoemail").val(); 
                        var tpersona = $("#tpersona").val(); 
                        var ciudad = $("#ciudad").val(); 
                        var rfiscal = $("#rfiscal").val(); 
                        var direccion = $("#nuevodireccion").val(); 
                        var puntov = $("#nuevopuntov").val(); 
                        var reprelegal = $("#reprelegal").val(); 
                        var rutajs="clienteRapido";
                        
                        $.ajax({
                           url:"./views/clienteRapido.php",
                           type:"POST",
                           async:true,
                           data:{nit:nit,nombre:nombre,telefono:telefono,email:email,dv:dv,ciudad:ciudad,tpersona:tpersona,
                           rfiscal:rfiscal,tdocumento:tdocumento,apellido:apellido,direccion:direccion,puntov:puntov,reprelegal:reprelegal,rutajs:rutajs},
                           success:function(response){
                                console.log(response);
                                $("#datoscliente").html(response);
                                $("#formucliente").slideUp();
                                $("#aocultar").slideUp();
                                $("#guardar").slideUp();
                           },
                           error:function(error){
                           }
                        });
                    }else{
                        alert("Todos los campos deben ser diligenciados ; )");
                    }
                });
                
                $("#aocultar").click(function(e){
                    e.preventDefault();
                    $("#formucliente").slideUp();
                    $("#ocultar").slideUp();
                    $("#guardar").slideUp();
                    $("#anuevocliente").slideDown();
                   
                });  
            }); 
            </script>
            
            ';
        }


printf($template);
    

?>