<?php
    
    class CiudadesController{
        private $model;
        private $envioemail;
        
        
        public function __construct(){
            $this->model=new CiudadesModel();
        }
        
        public function set($ciudades_data=array()){
            return  $this->model->set($ciudades_data);
        }
        public function get($ciudades =''){
             return  $this->model->get($ciudades);
        }
        public function getCodigo($ciudades =''){
             return  $this->model->getCodigo($ciudades);
        }
        public function getCodigoDeparta($ciudades =''){
             return  $this->model->getCodigoDeparta($ciudades);
        }
        public function getRegn($ciudades =''){
             return  $this->model->getRegn($ciudades);
        }
        public function getDep($ciudades =''){
             return  $this->model->getDep($ciudades);
        }
        
        public function getlista($ciudades =''){
             return  $this->model->getlista($ciudades);
        }
        
        public function del($ciudades =''){
             return  $this->model->del($ciudades);
        }
        public function edit($ciudades_data=array()){
             return  $this->model->edit($ciudades_data);
        }
        
        public function queryBuscar($ciudades =''){
            return  $this->model->queryBuscar($ciudades);
        }
        
        
    }
?>
