<?php
    
    class ArticulosModel extends Model{
        
        //ok
        public function set($articulos_data = array()){
            
        }
        public function subirMasivos($articulos_data = array()){
            
        }
         //ok
        public function get($art = ''){
            if($this->query=($art != '')){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            $this->query="SELECT art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva ,art.impoconsumo,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo, art.foto, art.detalles, art.pvpantes, art.tienda, art.favoritos
        
                        FROM articulos AS art 
                        LEFT JOIN tablas AS tbl ON art.linea = tbl.codigo  
                        LEFT JOIN tablas AS tbg ON art.grupo = tbg.codigo 
                        WHERE art.codigo LIKE '%$art%' OR art.descripcion LIKE'%$art%' OR art.referencia LIKE '%$art%' OR art.regn = '$art' AND art.tienda='t'
                        ORDER BY art.descripcion";
                        
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            }else{    
                $this->db_open();
                $this->preparar=$this->conn->prepare("SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo, art.foto, art.detalles, art.pvpantes, art.tienda, art.favoritos
                            FROM articulos AS art 
                            LEFT JOIN tablas AS tbl ON art.linea = tbl.codigo  
                            LEFT JOIN tablas AS tbg ON art.grupo = tbg.codigo   
                            WHERE art.tienda='t'
                            ORDER BY art.descripcion");
                $this->preparar->execute();
                $this->preparar->store_result();
                $meta = $this->preparar->result_metadata();
                $fields=$meta->fetch_fields();
                $result=[];
                $ref_result=[];
                foreach($fields as $field){
                    $result[$field->name]=null;
                    $ref_result[]=&$result[$field->name];
                }
                call_user_func_array(array($this->preparar, 'bind_result'),$ref_result);
                
                $data=[];
                
                while ($this->preparar->fetch()){
                    $data[]=$result;
                }
                $this->preparar->free_result();
                $this->conn->close();
            }
            
            return $data;
            
        }
        public function getTienda($art = ''){
                $this->db_open();
                $this->query=("  SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo, art.foto,art.pvpantes, art.detalles, art.favoritos
                        FROM articulos AS art 
                        LEFT JOIN tablas AS tbl 
                        ON art.linea = tbl.codigo  
                        LEFT JOIN tablas AS tbg 
                        ON art.grupo = tbg.codigo 
                        WHERE art.tienda='t'
                        GROUP BY art.codigo
                        ORDER BY art.pventa
                        
                        LIMIT 0,10");
                $this->get_query($this->query);
                foreach($this->rows as $key=>$valor){
                    $data[$key]=$valor;
                }
                if(empty($data)){$data='0';}
            
            
            return $data;
            
        }
        //ok
        public function del($regn=''){
            $this->db_open();
            $regn = $this->conn->real_escape_string($regn);
            $this->query = "DELETE FROM articulos WHERE regn ='$regn'";
            $this->origen="Articulo";
            $this->actividad="Elimina";
            $this->objeto=$regn;
            $this->set_query();           
            
        }
        //ok
        public function edit($articulos_data = array()){
        
        }
        //ok
        public function queryBuscar($art = ''){
            if($this->query=($art != '')){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            
            $this->query="SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo, art.foto, art.detalles, art.pvpantes, art.tienda, art.favoritos
        
                        FROM articulos AS art 
                        LEFT JOIN tablas AS tbl 
                        ON art.linea = tbl.codigo  
                        LEFT JOIN tablas AS tbg 
                        ON art.grupo = tbg.codigo 
                        WHERE art.tienda='t' AND art.descripcion LIKE'%$art%' 
                        GROUP BY art.codigo
                        ORDER BY art.pventa
                        LIMIT 0,20";
                        
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="0";
            }
            }else{    
                $this->db_open();
                $this->query=("  SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo, art.foto, art.detalles, art.pvpantes, art.tienda, art.favoritos
                        FROM articulos AS art 
                        LEFT JOIN tablas AS tbl 
                        ON art.linea = tbl.codigo  
                        LEFT JOIN tablas AS tbg 
                        ON art.grupo = tbg.codigo 
                        WHERE art.tienda='t'
                        GROUP BY art.codigo
                        ORDER BY art.pventa
                        
                        LIMIT 0,10");
                $this->get_query($this->query);
                foreach($this->rows as $key=>$valor){
                    $data[$key]=$valor;
                }
                if(empty($data)){$data='0';}
            }
            
            return $data;
        
        }
        
        public function listaBusqueda($art = ''){
            if($this->query=($art != '')){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            
            $this->query="SELECT codigo, descripcion, inv_cant, pventam,pventa, regn,referencia
                        FROM articulos
                        WHERE codigo LIKE '%$art%' OR descripcion LIKE'%$art%' OR referencia LIKE '%$art%' 
                        GROUP BY codigo
                        ORDER BY descripcion
                        LIMIT 0,6";
                        
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="0";
            }
            }else{    
                $this->db_open();
                $this->query=("SELECT codigo, descripcion, inv_cant, pventam,pventa, regn,referencia
                        FROM articulos
                        WHERE codigo LIKE '%$art%' OR descripcion LIKE'%$art%' OR referencia LIKE '%$art%' 
                        GROUP BY codigo
                        ORDER BY descripcion
                        LIMIT 0,6");
                $this->get_query($this->query);
                foreach($this->rows as $key=>$valor){
                    $data[$key]=$valor;
                }
                if(empty($data)){$data='0';}
            }
            
            return $data;
        
        }
        
        public function listaNegativos($art = ''){
            if($this->query=($art != '')){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            
            $this->query="SELECT codigo, descripcion, inv_cant, pventam,pventa, regn,referencia
                        FROM articulos
                        WHERE inv_cant <0
                        GROUP BY codigo
                        ORDER BY descripcion";
                        
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="0";
            }
            }else{    
                $this->db_open();
                $this->query=("SELECT codigo, descripcion, inv_cant, pventam,pventa, regn,referencia
                        FROM articulos
                        WHERE inv_cant <0 AND codigo LIKE '%$art%' 
                        GROUP BY codigo
                        ORDER BY descripcion
                        LIMIT 0,6");
                $this->get_query($this->query);
                foreach($this->rows as $key=>$valor){
                    $data[$key]=$valor;
                }
                if(empty($data)){$data='0';}
            }
            
            return $data;
        
        }
        
        public function listaBusquedaB($art = '',$array_paginacion=array()){
            foreach($array_paginacion as $key=>$value){
                $$key=$value;
            }
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            $pagina = $this->conn->real_escape_string($pagina);
            $numero_paginas = $this->conn->real_escape_string($numero_paginas);
            $registrosXpagina = $this->conn->real_escape_string($registrosXpagina);
            
            if($this->query=($art != '')){
            
            $this->query="SELECT codigo, descripcion, inv_cant, pventam,pventa, regn,referencia
                        FROM articulos
                        WHERE codigo LIKE '%$art%' OR descripcion LIKE'%$art%' OR referencia LIKE '%$art%' 
                        GROUP BY codigo
                        ORDER BY descripcion
                        LIMIT $pagina,$registrosXpagina";
                        
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="0";
            }
            }else{    
                $this->db_open();
                $this->query=("SELECT codigo, descripcion, inv_cant, pventam,pventa, regn,referencia
                        FROM articulos
                        WHERE codigo LIKE '%$art%' OR descripcion LIKE'%$art%' OR referencia LIKE '%$art%' 
                        GROUP BY codigo
                        ORDER BY descripcion
                        LIMIT $pagina,$registrosXpagina");
                $this->get_query($this->query);
                foreach($this->rows as $key=>$valor){
                    $data[$key]=$valor;
                }
                if(empty($data)){$data='0';}
            }
            
            return $data;
        
        }
        
        public function buscarRegn($art = ''){
            if($this->query=($art != '')){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            
            $this->query="SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo, art.foto, art.cdimpo
        
                        FROM articulos AS art 
                        LEFT JOIN tablas AS tbl 
                        ON art.linea = tbl.codigo  
                        LEFT JOIN tablas AS tbg 
                        ON art.grupo = tbg.codigo 
                        WHERE art.regn = '$art' 
                        GROUP BY art.codigo
                        ORDER BY art.descripcion
                        LIMIT 0,20";
                        
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="0";
            }
            }else{    
                $this->db_open();
                $this->query=("  SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo, art.foto
                        FROM articulos AS art 
                        LEFT JOIN tablas AS tbl 
                        ON art.linea = tbl.codigo  
                        LEFT JOIN tablas AS tbg 
                        ON art.grupo = tbg.codigo 
                        GROUP BY art.codigo
                        ORDER BY art.descripcion
                        
                        LIMIT 0,10");
                $this->get_query($this->query);
                foreach($this->rows as $key=>$valor){
                    $data[$key]=$valor;
                }
                if(empty($data)){$data='0';}
            }
            
            return $data;
        
        }
        
        public function buscarCodigo($art = ''){
            if($this->query=($art != '')){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            
            $this->query="SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo, art.foto, art.cdimpo, art.detalles, art.pvpantes, art.tienda, art.favoritos
        
                        FROM articulos AS art 
                        LEFT JOIN tablas AS tbl 
                        ON art.linea = tbl.codigo  
                        LEFT JOIN tablas AS tbg 
                        ON art.grupo = tbg.codigo 
                        WHERE art.codigo = '$art' 
                        GROUP BY art.codigo
                        ORDER BY art.pventa
                        LIMIT 0,20";
                        
            $this->get_query();
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="0";
            }
            }else{    
                $this->db_open();
                $this->query=("  SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo, art.foto
                        FROM articulos AS art 
                        LEFT JOIN tablas AS tbl 
                        ON art.linea = tbl.codigo  
                        LEFT JOIN tablas AS tbg 
                        ON art.grupo = tbg.codigo 
                        GROUP BY art.codigo
                        ORDER BY art.descripcion
                        
                        LIMIT 0,10");
                $this->get_query($this->query);
                foreach($this->rows as $key=>$valor){
                    $data[$key]=$valor;
                }
                if(empty($data)){$data='0';}
            }
            
            return $data;
        
        }
        //?
        public function buscar($art = ''){
        $this->db_open();
            $art = $this->conn->real_escape_string($art);
            $this->query=($art != '')
                ?"SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva ,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo
        
                        FROM articulos AS art 
                        INNER JOIN tablas AS tbl ON art.linea = tbl.codigo  
                        INNER JOIN tablas AS tbg ON art.grupo = tbg.codigo 
                        WHERE art.codigo LIKE '%$bus%' OR art.descripcion LIKE'%$bus%' OR art.referencia LIKE '%$bus%' OR art.regn = '$bus' 
                        ORDER BY art.descripcion"
                        
                
                :"SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva ,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo
        
                        FROM articulos AS art 
                        INNER JOIN tablas AS tbl ON art.linea = tbl.codigo  
                        INNER JOIN tablas AS tbg ON art.grupo = tbg.codigo  
                        ORDER BY art.descripcion
                        ";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if(!empty($data)){
                return $data;
            }
        
        }
        //?
        public function datos($art = ''){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            $this->query=($art != '')
                ?"SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva  ,art.impoconsumo,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo
        
                        FROM articulos AS art 
                        INNER JOIN tablas AS tbl ON art.linea = tbl.codigo  
                        INNER JOIN tablas AS tbg ON art.grupo = tbg.codigo 
                        WHERE art.codigo LIKE '%$art%' OR art.descripcion LIKE'%$art%' OR art.referencia LIKE '%$art%' OR art.regn = '$art' 
                        ORDER BY art.descripcion"
                        
                
                :"SELECT DISTINCTROW art.regn , art.codigo ,art.linea ,art.grupo ,art.proveedor ,art.descripcion ,
                         art.iva ,art.impoconsumo ,art.estado ,art.pventa ,art.pventam ,art.pventa1 ,art.pventa2 ,art.pventa3 ,art.pcosto ,art.pcosto1 ,art.cuentac ,art.minimo ,art.maximo ,
                         art.descuento ,art.referencia ,art.codebar ,art.unidad ,art.inv_cant ,art.inv_cantb ,art.Fechainv ,art.fechacre ,art.fechag ,art.inv_vprom ,
                         art.cre ,art.unidemp,tbl.descripcion AS des_linea, tbg.descripcion AS des_grupo
        
                        FROM articulos AS art 
                        INNER JOIN tablas AS tbl ON art.linea = tbl.codigo  
                        INNER JOIN tablas AS tbg ON art.grupo = tbg.codigo  
                        ORDER BY art.descripcion";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }

            return $data;
        }
        //Factura documento
        public function bcodigo($art = ''){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            $this->query="SELECT regn , codigo ,proveedor ,descripcion ,iva , impoconsumo ,estado ,pventa ,pventam ,pventa1 ,pventa2 ,pventa3 ,cuentac,pcosto,
                         descuento ,referencia ,codebar ,unidad ,inv_cant ,inv_cantb ,Fechainv 
                        FROM articulos 
                        WHERE codigo = '$art' AND pventa > 0 AND pventa >= pventam";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            if(empty($data)){
                $this->query="SELECT regn , codigo ,proveedor ,descripcion ,iva , impoconsumo ,estado ,pventa ,pventam ,pventa1 ,pventa2 ,pventa3 ,cuentac,pcosto,
                         descuento ,referencia ,codebar ,unidad ,inv_cant ,inv_cantb ,Fechainv 
                        FROM articulos 
                        WHERE codebar = '$art' AND pventa > 0 AND pventa >= pventam";
                        
                $this->get_query();
                foreach($this->rows as $key=>$valor){
                    $data[$key]=$valor;
                }
            }
            
            if(!empty($data)){
                return $data;
            }
        }
        
        public function bccodigo($art = ''){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            $this->query="SELECT regn , codigo ,proveedor ,descripcion ,iva , impoconsumo ,estado ,pventa ,pventam ,pventa1 ,pventa2 ,pventa3 ,cuentac,pcosto,
                         descuento ,referencia ,codebar ,unidad ,inv_cant ,inv_cantb ,Fechainv 
                        FROM articulos 
                        WHERE codigo = '$art' ";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            if(empty($data)){
                $this->query="SELECT regn , codigo ,proveedor ,descripcion ,iva , impoconsumo ,estado ,pventa ,pventam ,pventa1 ,pventa2 ,pventa3 ,cuentac,pcosto,
                         descuento ,referencia ,codebar ,unidad ,inv_cant ,inv_cantb ,Fechainv 
                        FROM articulos 
                        WHERE codebar = '$art' ";
                        
                $this->get_query();
                foreach($this->rows as $key=>$valor){
                    $data[$key]=$valor;
                }
            }
            
            if(!empty($data)){
                return $data;
            }
        }
//Gereciamiento del margen 
        public function margenCodigo($art = ''){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            $this->query="SELECT a.regn , a.codigo , a.proveedor ,a.descripcion ,a.iva , a.impoconsumo ,a.estado ,a.pventa ,
                            a.pventam , a.pventa1 , a.pventa2 , a.pventa3 , a.cuentac,a.pcosto,a.pcosto1,
                            a.descuento , a.referencia , a.codebar ,a.unidad , a.inv_cant , a.inv_cantb , a.Fechainv , a.grupo , g.descripcion as grdesc,
                            a.unidemp
                        FROM articulos AS a
                        LEFT JOIN tablas AS g
                        ON a.grupo = g.codigo
                        WHERE a.codigo LIKE '$art' ";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            if(empty($data)){
                $data="";
            }

            return $data;
        }
        
        public function articulosd($art = ''){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            $this->query="SELECT ar.descripcion, ar.codigo, ar.inv_cant, ar.regn, ar.pventa, ar.pventam,ar.pventa1,ar.pventa2,ar.pventa3,ar.iva,ar.impoconsumo,
                            ar.pcosto,ar.pcosto1
                        FROM articulosd AS a
                        LEFT JOIN articulos AS ar
                        ON a.codigoart = ar.codigo
                        WHERE a.codigo LIKE '$art' ";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            if(empty($data)){
                $data="";
            }

            return $data;
        }
        
        public function margen($articulos_data = array()){
            
        }
        
        public function editDetalles($articulos_data = array()){
            
        }
        
        public function contarArticulos($art = ''){
            $this->db_open();
            $art = $this->conn->real_escape_string($art);
            $this->query="select count(*) AS num from articulos ";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            
            if(empty($data)){
                $data="";
            }

            return $data;
        }
        
        public function setEmailTienda($articulos_data = array()){
            foreach($articulos_data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            }
        $foto='';
        $this->query = "INSERT INTO solicitud_tiendaonline SET regn= 0, nombre=?,celular=?,email=?,solicitud=?,respuesta=?" ;
        $this->db_open();
        $this->preparar=$this->conn->prepare($this->query);
        $this->preparar->bind_param("sssss",$nombre,$celular,$email,$solicitud,$respuesta);
        $this->preparar->execute();
            if($this->preparar->affected_rows != -1){
                echo '<div class="centrar">
                            <h3 class="titulo">Hemos recibido tu solicitud</h3>
                        </div> '; 
            }else{
                echo '<div class="centrar">
                        <h3 class="resaltaralerta">No se realizo la operacion,<br> Es posible que el articulo ya exista</h3>
                    </div>';
            }   
        $this->preparar->free_result();
        $this->conn->close();
        }
        

        /*public function __destruct(){
            unset($this);
        }*/
   
   
    }
?>