<?php

abstract class Model {
    private static $db_hostd = 'mysql:host=190.8.176.173';
    private static $db_host = '190.8.176.173';
    private static $db_user = 'fciempre_acelsoportes' ;
    protected $email = 'arias212@hotmail.com';
    private static $db_pass = 'Acelsoportes2020$';
    private static $db_name = 'fciempre_fcicweb';
    private static $db_named = 'dbname=fciempre_acelsoportes';
    private static $db_charset ='utf8';
    protected $conn;
    protected $namebd;
    protected $origen;
    protected $objeto;
    protected $actividad;
    protected $query;
    protected $filtros;
    protected $valores;
    protected $preparar;
    protected $params;
    protected $marcadores;
    
    protected $rows= array();
    protected $documentos= array();
    protected $db_name_fci;
    protected $num_variables;
    
    protected $resultado;
    protected $veri;
    protected $ok;
    protected $database;
    
    abstract protected function set();
    abstract protected function get();
    abstract protected function del();
    
    protected function db_open(){  
           $this->database="fciempre_acelsoportes";
           $this->conn=new mysqli(self::$db_host,
                                 self::$db_user,
                                 self::$db_pass,
                                 $this->database);
           $this->conn->set_charset(self::$db_charset); 
            if (mysqli_connect_errno()) {
                printf("Falló la conexión: %s\n", mysqli_connect_error());
                exit();
            }
    }
    
    protected function db_openPDO(){
           $this->database="fciempre_acelsoportes";
           $conectar='"mysql:host='.self::$db_host.'; dbname='.$this->database.'"';
           $usuario=self::$db_user;
           $pass=self::$db_pass;
           
            try{   
                $conn=new PDO($conectar,$usuario,$pass);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }catch(exception $e){
                 die('error: '.$e->getMessage().'<br/>');
                 echo "Linea".$e->getLine();
            }  
    }
        
    protected function db_close (){
        $this->conn->close();
    }
    
    protected function set_query(){
        $this->db_open();
        $this->conn->query($this->query);
        if($this->conn->affected_rows >=1){
            $confirmacion="";
            $mail_controller = new EmpresasController();
            $mail=$mail_controller->configFE();
            if($this->origen != "contenidodocumento"){
                $para=$this->email;
                $asunto="$this->origen : $this->actividad ";
                $textomail=
                '<html>
                    <head><meta charset="gb18030">
                        
                        <meta name="viewport" content="width=device-width, initial-scale=1">
                        
                        <title>FCICWEB-Facturacion electronica-cartera-inventarios-contabilidad</title>
                        <meta name="descripcion" conten="FCICWEB-Facturacion electronica-cartera-inventarios-contabilidad">
                        <link rel="shortcut icon" type="image/png" href="./public/img/favicon.png">
                        <!--<link rel="stylesheet" href="./public/css/responsimple.min.css">-->
                        <!--<link rel="stylesheet" href="./public/css/fcicweb.css">-->
                        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
                        <style>
                            body{
                                @import url("https://fonts.googleapis.com/css?family=Poppins:20");
                                font-family:Candara;
                            }
                            .prueba{
                                box-shadow:0px 2px 5px 1px rgba(0,0,0,.2);
                                border-radius:5px;
                                margin-top:10px;
                                margin-bottom:10px;
                                padding:20px;
                                text-align:center;
                                font-size:2em;
                                border:1px solid;
                                border-color: rgba(0,0,0,.2);
                            }
                            .centrar{
                                text-align:center;
                            }
                        </style>
                    </head>
                    <body>
                    <figure class="centrar">
                        <div class="centrar">
            		        <img class="centrar" src="https://fciempresas.com/fcicweb_inst//public/img/usuarios/logo-2.png" alt="FCICWEB"  >
            		    </div>
            		</figure>
                        <p class="prueba">'.$_SESSION['idemp'].' ha creado el movimiento '.$_POST['rutajs'].' con exito por el usuario: '.$_SESSION['acceso'].'</p>
                        <h1 class="centrar">Prosperidad empresarial</h1>
                    <body>
                </html>    ';
                $arraya_mail=array(
                    'para'=>$para,
                    'asunto'=>$_SESSION['idemp']." ".$_POST['rutajs'],
                    'cuerpomail'=>$textomail
                    );
                $mail_controller= new PhpmailerController();
                $mail = $mail_controller->enviarEmail($arraya_mail);
                /*
                $v2='From: FCICWEB empresas <soporte@fciempresas.com>\r\n';
                $v2.='MIME-Version: 1.0\r\n';
                $v2.='Content-type: text/html; charset=iso-8859-1' . "\r\n";
                $exito = mail($para,$asunto, $textomail, $v2);
                */
            }
        }else{
            if($this->origen != "contenidodocumento" || $this->origen != "facturapp"){
            echo '<div class="centrar">
                    <h3 class="resaltaralerta">No se realizo la operacion</h3>
                </div>';
            
            }
            $confirmacion="error";
        }    
        $this->db_close();
        return $confirmacion;
    }
    
    protected function get_query(){
        $this->db_open();
        $result=$this->conn->query($this->query); 
        while($this->rows[]=$result->fetch_assoc());
        $result->close();
        $this->db_close();
        return array_pop($this->rows);
    }
    
    protected function get_queryDocu(){
        $this->db_open();
        $result=$this->conn->query($this->query); 
        while($this->documentos[]=$result->fetch_assoc());
        $result->close();
        $this->db_close();
        return array_pop($this->documentos);
    }
    
    protected function db_open_veri(){
        try{   
            $this->veri=new mysqli(self::$db_host,
                                  self::$db_user,
                                  self::$db_pass,
                                  self::$db_name);
            $this->veri->set_charset(self::$db_charset); 
        }catch(exception $e){
             die('error: '.$e->getMessage().'<br/>');
             echo "Linea".$e->getLine();
           } 
           //return $this->veri;
    }
    
    function db_close_veri (){
        $this->veri->close();
    }
    
    protected function setQueryPre(){
        $this->db_openPDO();
        $this->prepare=$this->conn($this->query) ;
        $this->prepare->execute();
        $this->rows=$this->prepare->fetchAll();
          
        $this->db_close();
    }
    
    protected function getQueryPre($art){
        $this->db_openMysqi();
                $this->prepare=mysqli_prepare($this->conn, $this->query) ;
                $this->ok=mysqli_stmt_bind_param($this->prepare,"sssi",$art,$art,$art,$art);
        $this->ok=mysqli_stmt_execute($this->prepare);
        //$result=$this->conn->query($this->query); 
        while($this->rows[]=$this->ok->fetch_assoc());
        $this->prepare->close();
        $this->db_close();
        return array_pop($this->rows);
    }
    
    public function limpiar(){
        $this->rows[]='';
        $this->query='';
        $this->preparar='';
    }
}

    