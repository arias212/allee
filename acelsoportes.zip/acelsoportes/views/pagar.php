<?php
    require_once('../controllers/Autoload.php');
    $Autoload=new Autoload();
    
    $articulos_controller= new ArticulosController();
    $articulos=$articulos_controller->buscarCodigo($_POST['codigo']);
    //$numdoc = $ultord[0]['ultdoc'];
    $numdoc = (empty($numdoc)) ? 1 : $numdoc;
    $getpagos_controller=new PagosonlineController();
    $getpagos=$getpagos_controller->getConfigPagos();
    //var_dump($getpagos);
    $nitemp=(!empty($getpagos))?$getpagos[0]['nit']:"";//"https://sandbox.checkout.payulatam.com/ppp-web-gateway-payu/";
   $urlForm=(!empty($getpagos))?$getpagos[0]['urlenvio']:"";//"https://sandbox.checkout.payulatam.com/ppp-web-gateway-payu/";
    $apiKey=(!empty($getpagos))?$getpagos[0]['apikey']:"";//"4Vj8eK4rloUd272L48hsrarnUA";
    $merchanId=(!empty($getpagos))?$getpagos[0]['merchanid']:"";//"508029";
    $acountdId=(!empty($getpagos))?$getpagos[0]['acountdid']:"";//"512321";
    $referenciapago=(!empty($getpagos))?$getpagos[0]['referenciapago']."-".$numdoc:"";
    $descripcionpago=(!empty($getpagos))?$getpagos[0]['descripcionpago']:"";//$_SESSION['idemp'].' Ventas On-Line';
    $moneda=(!empty($getpagos))?$getpagos[0]['moneda']:"";//"COP";
    $responseUrl=(!empty($getpagos))?$getpagos[0]['responseurl']:"";//"https://www.fciempresas.com/fcicweb_inst/public/pa/responsepayu.php";
    $confirmationUrl=(!empty($getpagos))?$getpagos[0]['confirmationurl']:"";//"https://www.fciempresas.com/fcicweb_inst/public/pa/responsepayuconfir.php";
    $modo_operacion=(!empty($getpagos))?$getpagos[0]['modooperacion']:"";//1;
    $signature=md5($apiKey."~".$merchanId."~".$referenciapago."~".$_POST['valor']."~".$moneda);
    //var_dump($_POST);
    $html='
    
    <div class="menuNavegacion" style="font-size:0.75em;">
    <h1 class="titulo centrar">Facturar a nombre de :
        <ul class=" ">
            <li>
             <form method="post" action="">
              <input name="codigo"        type="hidden" id="codigo" value="'.$articulos[0]['codigo'].'"   >
              <input name="valor"         type="hidden" id="valor" value="'.$_POST['valor'].'"   >
              <input name="cant"         type="hidden"  id="cant" value=""   >
              <input name="buscarnit"     type="text" id="buscarnit" name="buscarnit" placeholder="Ingresa el NIT" class="centrar" required>
              <div class="centrar" id="restercero" ></div>
              <br><input name="enviar"        type="submit" id="confirmar"  value="Confirmar" class="">
            </form>
            </li>
        </ul>
    </div>
    <div class="menuNavegacion">
        <ul class=" ">
            <li>
             <form method="post" action="'.$urlForm.'">
              <input name="merchantId"    type="hidden"  value="'.$merchanId.'"   >
              <input name="accountId"     type="hidden"  value="'.$acountdId.'" >
              <input name="description"   type="hidden"  value="'.$descripcionpago.'"  >
              <input name="referenceCode" type="hidden"  value="'.$referenciapago.'" >
              <input name="amount"        type="hidden"  value="'.$_POST['valor'].'"   >
              <input name="tax"           type="hidden"  value="0"  >
              <input name="taxReturnBase" type="hidden"  value="0" >
              <input name="currency"      type="hidden"  value="'.$moneda.'" >
              <input name="signature"     type="hidden"  value="'.$signature.'"  >
              <input name="test"          type="hidden"  value="'.$modo_operacion.'" >
              <input name="name"          type="hidden"  value="das@g.vp" >
              <input name="responseUrl"    type="hidden"  value="'.$responseUrl.'" >
              <input name="confirmationUrl"    type="hidden"  value="'.$confirmationUrl.'" >
              <input name="Submit"        type="submit" id="Submit" value="" class="btnpago sombra" style="display:none;">
            </form>
            </li>
        </ul>
    </div>
    <script>
        $("#document").ready(function(){
           
           $("#buscarnit").keyup(function(e){
               e.preventDefault();
               var nit = $(this).val();
               var accion = "buscarnit";
               var rutajs="datoscliente";
               
               if (nit !=""){
                   $.ajax({
                       url:"./views/datoscliente.php",
                       type:"POST",
                        dataType:"html",
                       async:true,
                       data:{accion:accion, nit:nit,rutajs:rutajs},
                       
                       success:function(response){
                               if(response!="error"){
                               var informacion = JSON.stringify(response);
                               //console.log(informacion)
                               //alert(response);
                                   $("#restercero").html(response);
                                   
                               }else{
                                   $("#restercero").html("");
                               }
                               
                               
                       }, error: function(error){}
                    });
               }    
           });
           
           $("#confirmar").click(function(e){
               e.preventDefault();
               var codigo = $("#codigo").val();
               var nit = $("#buscarnit").val();
               var valor = $("#valor").val();
               var vendedor = $("#listavendedor").val();
               var cant = $("#cant").val();
               var email= $("#email").val();
               var rutajs="confirmarpago";
               $(this).slideUp();
               //$("#respuesta").html("");
               if (nit !=""){
                   $.ajax({
                       url:"./views/confirmarpago.php",
                       type:"POST",
                        dataType:"html",
                       async:true,
                       data:{codigo:codigo, valor:valor, nit:nit,rutajs:rutajs,cant:cant,vendedor:vendedor,email:email},
                       
                       success:function(response){
                            $("#Submit").slideDown();
                            
                               if(response!="error"){
                               var informacion = JSON.stringify(response);
                               //console.log(informacion)
                               //alert(response);
                                   
                                //$("#restercero").html(response);
                                   
                               }else{
                                   $("#restercero").html("");
                               }
                               
                               
                       }, error: function(error){}
                    });
               }    
           });
           $("#buscarnit").focus();
        });
    </script>  
<div class="infoPrincipal">
    <div class="infoEmpresa">
        <h1 class="titulo centrar">'.$articulos[0]['descripcion'].'</h1>
        <span class="resaltarcolor centrar">'.$articulos[0]['detalles'].'</span><br>
        <h1 class="resaltarcolor centrar" style="font-size:2em;">Antes <del> $ '.number_format($articulos[0]['pvpantes'],2).' </del></h1>
        <h1 class="resaltarcolor centrar" style="font-size:3em;">$ '.number_format($articulos[0]['pventa'],2).'</h1><br>
        <div style="width:90%;" class="centrar">
            <img src="../app/public/img/usuarios/acelsoportes/fotos_articulos/'.$articulos[0]['foto'].'"  class="centrar" id="" style="width:90%;">
        </div> 
    </div>
</div>
        ';
    
    print($html);
?>