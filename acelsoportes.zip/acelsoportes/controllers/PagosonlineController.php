<?php
    
    class PagosonlineController{
        private $model;
        private $envioemail;
        
        
        public function __construct(){
            $this->model=new PagosonlineModel();
        }
        
        public function set($data=array()){
            return  $this->model->set($data);
        }
        
        public function get($data =''){
             return  $this->model->get($data);
        }
        
        public function getConfigPagos($data =''){
             return  $this->model->getConfigPagos($data);
        }
        
        public function getlista($data =''){
             return  $this->model->getlista($data);
        }
        
        public function del($data =''){
             return  $this->model->del($data);
        }
        public function edit($data=array()){
             return  $this->model->edit($data);
        }
        
        public function empresa($data=array()){
            return  $this->model->empresa($data);
        }
        public function response($data=array()){
            return  $this->model->response($data);
        }
        public function confiPagosOnline($data=array()){
            return  $this->model->confiPagosOnline($data);
        }
        
        
    }
?>
