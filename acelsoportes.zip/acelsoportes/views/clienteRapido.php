<?php
require_once('../controllers/Autoload.php');
$Autoload=new Autoload();
    
    $clientenuevo= array(
        'nit'=>$_POST['nit'],
        'nombre'=>$_POST['nombre'],
        'apellido'=>$_POST['apellido'],
        'telefono'=>$_POST['telefono'],
        'email'=>$_POST['email'],
        'tdocumento'=>$_POST['tdocumento'],
        'dv'=>$_POST['dv'],
        'tpersona'=>$_POST['tpersona'],
        'direccion'=>$_POST['direccion'],
        'ciudad'=>$_POST['ciudad'],
        'rfiscal'=>$_POST['rfiscal'],
        'puntov'=>$_POST['puntov'],
        'reprelegal'=>$_POST['reprelegal']
        );
    //var_dump($clientenuevo);
    $cliente_controller = new ClientesController();
    $cliente = $cliente_controller->setRapido($clientenuevo);
    
    $cliente_controller = new ClientesController();
    $puntov_controller = new ClientesController(); 
    
    $cliente = $cliente_controller->getNit($_POST['nit']);
    $puntov = $puntov_controller->puntov($_POST['nit']);
    
    $vendedores_controller = new VendedoresController();
    $vendedores= $vendedores_controller->get();
    
    $puntov_select='';
    for($n=0;$n< count($puntov);$n++){
        $puntov_select.='<option value="'.$puntov[$n]['puntov'].'">'.$puntov[$n]['puntov'].'</option>';
    }
    
    $vendedor_select='';
    $vendedores_controller = new VendedoresController();
    $vendedores= $vendedores_controller->get();
    if(!empty($vendedores)){
        for($n=0;$n<count($vendedores);$n++){
            $vendedor_select.='<option value="'.$vendedores[$n]['nit'].'">'.$vendedores[$n]['nombre'].'</option>';
        }
    }
    
    if(!empty($cliente)){
    $template='
    
    
        <h3 class="letras">DV: <span class="resaltarletras" id="nitcliente">'.$cliente[0]['dv'].'</span></h3>
        <h3 class="letras">Nombres: <span class="resaltarletras">'.$cliente[0]['nombre'].'</span></h3>
        <h3 class="letras">Apellidos: <span class="resaltarletras">'.$cliente[0]['apellido'].'</span></h3>
        <h3 class="letras">Razon social: <span class="resaltarletras">'.$cliente[0]['reprelegal'].'</span></h3>
        <h3 class="letras">Direccion: <span class="resaltarletras">'.$cliente[0]['direccion'].'</span></h3>
        <select name="listavendedor" id="listavendedor" class="input">
            <option value="">Selecciona el vendedor</option>
            '.$vendedor_select.'
        </select><br>
        <h3 class="letras">e-mail : <span id= "email" class="resaltarletras">'.$cliente[0]['email1'].'</span></h3>
        <label for="" class="letras">Punto de venta</label><br>
        <select name="listaclientes" id="puntov" class="input">
            '.$puntov_select.'
        </select>
        ';
    printf($template);
    }


    

?>