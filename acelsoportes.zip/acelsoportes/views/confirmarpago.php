<?php
    require_once('../controllers/Autoload.php');
    $Autoload=new Autoload();
    $articulos_controller= new ArticulosController();
    $articulos=$articulos_controller->buscarCodigo($_POST['codigo']);
    $getpagos_controller=new PagosonlineController();
    $getpagos=$getpagos_controller->getConfigPagos();
    $ultord_controller = new OrdenestiendaController();
    $ultord = $ultord_controller->ultfac();
    $numdoc = $ultord[0]['ultima_factura'];
    $numdoc = (empty($numdoc)) ? 1 : $numdoc;
    //var_dump($getpagos);
     $cabecerarem=array(
            'nit'=>$_POST['nit'],
            'puntov'=>'',
            'vendedor'=>$_POST['vendedor'],
            'observaciones'=>"",
            'efectivo'=>"",
            'tipopago'=>"",
            'fechav'=>"",
            'numeroapro'=>$signature,
            'totalfacpp'=>$articulos[0]['pventa'],
            'totaldescuentov'=>$articulos[0]['descuento'],
            'subtotal'=>$articulos[0]['pventa'],
            'totaliva'=>$articulos[0]['iva'],
            'totalimpo'=>$articulos[0]['impoconsumo'],
            'numdoc'=>$numdoc,
            'idpago'=>$getpagos[0]['referenciapago']);
            //var_dump($cabecerarem);     
    $contenido_controller= new OrdenestiendaController();
    $contenido=$contenido_controller->setPFacturasti($cabecerarem);
    $detalle_controller= new OrdenestiendaController();
    $detalle=$detalle_controller->detalleTiendaOnline($_POST['codigo'],$numdoc);
    $facturaspp_controller= new OrdenestiendaController();
    $facturaspp=$facturaspp_controller->facturaNumdoc($numdoc);
    //var_dump($_POST);
    $html='
    <div class="centrar" style="font-size:0.7em;" id="pagacon">
        
        <div name="" class=" centrar">
            
            <h1 class="resaltarcolor titulo">Facturado a :</h1>
            <label class="resaltarcolor">Sr(a)'.$facturaspp[0]['nombre']." ".$facturaspp[0]['apellido'].'</label><br>
            <label class="resaltarcolor">'.$facturaspp[0]['reprelegal'].'</label><br>
            <label class="resaltarcolor">NIT: '.$_POST['nit'].'</label><br>
            <label class="resaltarcolor">'.$facturaspp[0]['direccion'].'</label><br>
            <label class="resaltarcolor">'.$facturaspp[0]['email1'].'</label><br>
            <div name="datoscliente" class="centrar" id="cabeceraDocumentoCliente">
               
            </div>
        </div>
        
        
    </div>  
   
   
<div class="infoPrincipal">
    <div class="infoEmpresa">
        <h1 class="resaltarcolor centrar">'.strtoupper($articulos[0]['descripcion']).'</h1>
        <span class="resaltarcolor centrar">'.$articulos[0]['detalles'].'</span><br>
        <h1 class="resaltarcolor centrar" style="font-size:2em;">Antes <del> $ '.number_format($articulos[0]['pvpantes'],2).' </del></h1>
        <h1 class="titulo centrar" style="font-size:3em;">$ '.number_format($articulos[0]['pventa'],2).'</h1><br>
        <div style="width:90%;" class="centrar">
            <img src="./public/img/'.$articulos[0]['codigo'].'.png" class="" id="" style="width:270px;height:270px;">
        </div> <br>
        <a href="https://api.whatsapp.com/send?text=https://fciempresas.com/acelsoportes?id='.$articulos[0]['codigo'].'" data-text="COMPARTIR EN WHATSAPP" data-action="share/whatsapp/share" class="miestilo" style="border: none; margin: 10px 0; font-size: 16px;">
            <img border="0" src="./public/img/comwhatsapp.png" width="32px" height="32px" title="Comparte con tus contactos">
        </a>
        <a href="https://wa.me/0573117061694/?text=Hola" data-text="COMPARTIR EN WHATSAPP" data-action="share/whatsapp/share" class="miestilo" style="border: none; margin: 10px 0; font-size: 16px;">
            <img border="0" src="./public/img/logowhastapp.png" width="32px" height="32px" title="Chat con un experto Acel Soportes TV">
        </a>
        <a href="https://www.facebook.com/edilsonacel/" class="miestilo" style="border: none; margin: 10px 0; font-size: 16px;">
            <img border="0" src="./public/img/logofacebook.png" width="32px" height="32px" title="Visita nuestro fanpage">
        </a><br>
    </div>
</div>

        ';
    
    print($html);
?>