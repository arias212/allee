<?php
    
    class TdocumentoModel extends Model{

        
        public function set($data = array()){
            
            foreach($data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            } 
            
            $this->query = "INSERT INTO tablas SET regn='0', codigo=?,descripcion=?, descripcion1=?, usuario=?, tipo=12 "; 
            $this->db_open();
            $codigo=strtoupper($codigo);
            $descripcion=strtoupper($descripcion);
            $descripcion1=strtoupper($descripcion1);
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("ssss",$codigo,$descripcion,$descripcion1,$usuario);
            $this->preparar->execute();
            $this->origen="Banco";
            $this->actividad="Crear";
            $this->objeto=$descripcion;
                if($this->preparar->affected_rows != -1){
                    echo '<div class="centrar">
                                <h3 class="titulo">Banco guardado con exito </h3>
                            </div> '; 
                }else{
                    echo '<div class="centrar">
                            <h3 class="resaltaralerta">No se realizo la operacion,<br> Es posible que el banco ya exista</h3>
                        </div>';
                }   
        $this->preparar->free_result();
        $this->conn->close();
        }
         
        public function get($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE tipo = 12 AND descripcion LIKE'%$var%' OR regn='$var' 
                ORDER BY descripcion
                LIMIT 0,50"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = 12 
                ORDER BY descripcion
                LIMIT 0,10";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            return $data;
        }
        
        public function getlista($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE tipo = 12 AND descripcion LIKE'%$var%' OR regn='$var' 
                ORDER BY descripcion"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = 12 
                ORDER BY regn";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            return $data;
        }
        
        public function queryBuscar($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE codigo LIKE '%$var%' OR descripcion LIKE'%$var%' OR regn='$var' AND tipo = '12' 
                ORDER BY descripcion"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = '12' 
                ORDER BY descripcion";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }

            return $data;
        
        }
      
        public function del($var=''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query = "DELETE FROM tablas WHERE regn ='$var'";
            $this->set_query();   
            $this->origen="Banco";
            $this->actividad="Eliminado";
            $this->objeto=$var;
            
        }
        
        public function edit($var = array()){
            
            foreach($var as $key=>$value){
                $$key=$value;
            }  
            $codigo=strtoupper($codigo);
            $descripcion=strtoupper($descripcion);
            $descripcion1=strtoupper($descripcion1);
            $this->query = "UPDATE tablas SET codigo=?,descripcion=?, descripcion1=?, usuario=?, tipo=12 WHERE regn=?"; 
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("ssssi",$codigo,$descripcion,$descripcion1,$usuario,$regn);
            $this->preparar->execute();
            $this->origen="Banco";
            $this->actividad="Modificado";
            $this->objeto=$descripcion;
                if($this->preparar->affected_rows != -1){
                    echo '<div class="centrar">
                                <h3 class="titulo">Banco guardado con exito </h3>
                            </div> '; 
                }else{
                    echo '<div class="centrar">
                            <h3 class="resaltaralerta">No se realizo la operacion,<br> Es posible que el banco ya exista</h3>
                        </div>';
                }   
        $this->preparar->free_result();
        $this->conn->close();

        }

        /*public function __destruct(){
            unset($this);
        }*/
   
   
    }
?>