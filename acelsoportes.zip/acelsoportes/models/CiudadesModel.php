<?php
    
    class CiudadesModel extends Model{

        
        public function set($data = array()){
            
            foreach($data as $key=>$value){
               //VARIABLE DE VARIABLE 
                $$key=$value;
            } 
            
            $codigo=strtoupper($codigo);
            $descripcion=strtoupper($descripcion);
            $descripcion1=strtoupper($descripcion1);
            $this->query = "INSERT INTO tablas SET regn='0', codigo=?,descripcion=?, descripcion1=?, usuario=?, tipo=3 "; 
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("ssss",$codigo,$descripcion,$descripcion1,$usuario);
            $this->preparar->execute();
            $this->origen="Grupo";
            $this->actividad="Crear";
            $this->objeto=$descripcion;
                if($this->preparar->affected_rows != -1){
                }else{
                }   
        $this->preparar->free_result();
        $this->conn->close();
        }
         
        public function get($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE tipo = 3 AND descripcion LIKE'%$var%'
                ORDER BY descripcion
                LIMIT 0,20"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = 3 
                ORDER BY descripcion
                LIMIT 0,10";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            return $data;
        }
        
        public function getCodigo($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE tipo = 3 AND codigo ='$var'
                ORDER BY descripcion
                LIMIT 0,20"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = 3 
                ORDER BY descripcion
                LIMIT 0,10";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            return $data;
        }
        
        public function getCodigoDeparta($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE tipo = 9 AND codigo ='$var'
                ORDER BY descripcion
                LIMIT 0,20"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = 9 
                ORDER BY descripcion
                LIMIT 0,10";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            return $data;
        }
        
        public function getRegn($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE tipo = 3 AND regn ='$var'
                ORDER BY descripcion
                LIMIT 0,20"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = 3 
                ORDER BY descripcion
                LIMIT 0,10";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            return $data;
        }
        
        public function getlista($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE tipo = 3 AND descripcion LIKE'%$var%' OR regn='$var' 
                ORDER BY descripcion"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = 3 
                ORDER BY descripcion";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            return $data;
        }
        public function getDep($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE tipo = 9 AND codigo ='$var'  
                ORDER BY descripcion"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = 9 
                ORDER BY descripcion";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }
            return $data;
        }
        
        public function queryBuscar($var = ''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query=($var != '')
                ?"SELECT * 
                FROM tablas 
                WHERE codigo LIKE '%$var%' OR descripcion LIKE'%$var%' OR regn='$var' AND tipo = '3' 
                ORDER BY descripcion"

                :"SELECT * 
                FROM tablas 
                WHERE  tipo = '3' 
                ORDER BY descripcion";
                        
            $this->get_query();
            //echo "<br>". $num_registros=count($this->rows)." Registros <br>";
            
            foreach($this->rows as $key=>$valor){
                $data[$key]=$valor;
            }
            if (empty($data)){
                $data="";
            }

            return $data;
        
        }
      
        public function del($var=''){
            $this->db_open();
            $var = $this->conn->real_escape_string($var);
            $this->query = "DELETE FROM tablas WHERE regn ='$var'";
            $this->set_query();   
            $this->origen="Grupo";
            $this->actividad="Eliminado";
            $this->objeto=$var;
            
        }
        
        public function edit($var = array()){
            
            foreach($var as $key=>$value){
                $$key=$value;
            }  
            $codigo=strtoupper($codigo);
            $descripcion=strtoupper($descripcion);
            $descripcion1=strtoupper($descripcion1);
            $this->query = "UPDATE tablas SET codigo=?,descripcion=?, descripcion1=?, usuario=?, tipo=3 WHERE regn=?"; 
            $this->db_open();
            $usuario=$_SESSION['acceso'];  
            $this->preparar=$this->conn->prepare($this->query);
            $this->preparar->bind_param("ssssi",$codigo,$descripcion,$descripcion1,$usuario,$regn);
            $this->preparar->execute();
            $this->origen="Grupo";
            $this->actividad="Modificado";
            $this->objeto=$descripcion;
                if($this->preparar->affected_rows != -1){
                }else{
                }   
        $this->preparar->free_result();
        $this->conn->close();
        }

        /*public function __destruct(){
            unset($this);
        }*/
   
   
    }
?>