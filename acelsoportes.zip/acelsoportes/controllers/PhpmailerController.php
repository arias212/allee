<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '/home/fciempre/public_html/fcicweb_inst/views/librerias/phpmailer/Exception.php';
require '/home/fciempre/public_html/fcicweb_inst/views/librerias/phpmailer/PHPMailer.php';
require '/home/fciempre/public_html/fcicweb_inst/views/librerias/phpmailer/SMTP.php';


class PhpmailerController{
    
    public function enviarEmail($contenido){
        foreach($contenido as $key=>$value){
           //VARIABLE DE VARIABLE 
            $$key=$value;
        }
        $mail = new PHPMailer(true);                              
        try {
            //$mail->SMTPDebug = 4;                               // Habilitar el debug
        
            $mail->isSMTP();                                      // Usar SMTP
            $mail->Host = 'mail.fciempresas.com';  // Especificar el servidor SMTP reemplazando por el nombre del servidor donde esta alojada su cuenta
            $mail->SMTPAuth = true;                               // Habilitar autenticacion SMTP
            $mail->Username = 'soporte@fciempresas.com';                 // Nombre de usuario SMTP donde debe ir la cuenta de correo a utilizar para el envio
            $mail->Password = 'dqAFpp3g1228';                           // Clave SMTP donde debe ir la clave de la cuenta de correo a utilizar para el envio
            $mail->SMTPSecure = 'ssl';                            // Habilitar encriptacion
            $mail->Port = 465;                                    // Puerto SMTP                     
            $mail->Timeout       =   30;
            $mail->AuthType = 'LOGIN';
        
            //Recipients   
        
            $mail->setFrom('soporte@fciempresas.com');     //Direccion de correo remitente (DEBE SER EL MISMO "Username")
            $mail->addAddress($para);     // Agregar el destinatario
            $mail->addReplyTo('soporte@fciempresas.com');     //Direccion de correo para respuestas     
        
            //Content
            $mail->isHTML(true);                                  
            $mail->Subject = $asunto;
            $mail->Body    = $cuerpomail;
            
            $mail->send();
            //echo '<h2 class="resaltarcolor">El mensaje ha sido enviado</h2>';
        
        } catch (Exception $e) {
            //echo 'El mensaje no pudo ser enviado. Mailer Error: ', $mail->ErrorInfo;
        }
    }
}