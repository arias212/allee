<?php
$html='
<figure class="centrar">
        <div class="">
	        <img class="logo trasition cambioc borderRadius" src="./public/img/logoacelsoportes.png" alt="Acel soportes TV"  >
	    </div>
</figure>
<div class="divTienda centrar">

<h1 class="titulo">Envíanos tu solicitud </h1><br>
<label class="centrar titulo">En un plazo inferior a 12 horas resolveremos tus solicitudes</label><br>
<form method="POST">
    <input id="email" name="email" class="input" placeholder="tu@email.com"><br>
    <input id="nombre" name="nombre" class="input" placeholder="Nombres"><br>
    <input id="celular" name="celular" class="input" placeholder="Celular"><br>
    <textarea id="solicitud" name="solicitud" class="inputobservacion" placeholder="Solicitud"></textarea><br>
    <input type="submit" id="enviarmail" name="enviar" class="btnmail"><br>
</form>
</div>

<div class="centrar">
    <label class="centrar titulo resaltarcolor"><i class="fa fa-whatsapp"> 311 706 1694</i>   <br><i class="fa fa-phone" aria-hidden="true"> 032 662 2819 - 032 375 0154</i> </label><br>
    <label class="centrar titulo resaltarcolor"><i class="fa fa-map-marker" aria-hidden="true"> Calle 70 7b 37 </i></label><br>
    <label class="centrar titulo resaltarcolor">Barrio Alfonso López</label><br>
    <label class="centrar titulo resaltarcolor">Cali, Colombia</label><br>
    <p class="centrar letras ">Tu información está protegida con estándares de calidad <br>©Todos los derechos reservado ACEL SOPORTES TV  </p>
<div>    
';

print($html);
?>