<?php
    
    class VendedoresController{
        private $model;
        private $envioemail;
        
        
        public function __construct(){
            $this->model=new VendedoresModel();
        }
        
        public function set($vendedor_data=array()){
            return  $this->model->set($vendedor_data);
        }
        public function get($vendedores =''){
             return  $this->model->get($vendedores);
        }
        
        public function del($vendedores =''){
             return  $this->model->del($vendedores);
        }
        public function edit($vendedores_data=array()){
             return  $this->model->edit($vendedores_data);
        }
        
        public function queryBuscar($vendedores =''){
            return  $this->model->queryBuscar($vendedores);
        }
        
        
    }
?>
