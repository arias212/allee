<?php
    
    class ArticulosController{
        private $model;
        private $envioemail;
        
        
        public function __construct(){
            $this->model=new ArticulosModel();
        }
        
        public function set($articulo_data=array()){
            return  $this->model->set($articulo_data);
        }
        public function subirMasivos($articulo_data=array()){
            return  $this->model->subirMasivos($articulo_data);
        }
        public function get($articulo =''){
             return  $this->model->get($articulo);
        }
        
        public function setEmailTienda($articulo_data=array()){
             return  $this->model->setEmailTienda($articulo_data);
        }
        
        public function getTienda($articulo =''){
             return  $this->model->getTienda($articulo);
        }
        
        public function del($articulo =''){
             return  $this->model->del($articulo);
        }
        public function edit($articulo_data=array()){
             return  $this->model->edit($articulo_data);
        }
        
        public function queryBuscar($articulo =''){
            return  $this->model->queryBuscar($articulo);
        }
        
        public function listaBusqueda($articulo =''){
            return  $this->model->listaBusqueda($articulo);
        }
        
        public function listaNegativos($articulo =''){
            return  $this->model->listaNegativos($articulo);
        }
        
        public function listaBusquedaB($articulo ='',$array_paginacion=array()){
            return  $this->model->listaBusquedaB($articulo,$array_paginacion);
        }
        
        public function buscarRegn($articulo =''){
            return  $this->model->buscarRegn($articulo);
        }
        
        public function buscarCodigo($articulo =''){
            return  $this->model->buscarCodigo($articulo);
        }
        
        public function buscar($articulo =''){
            return  $this->model->buscar($articulo);
        }
        
        public function datos($articulo =''){
            return  $this->model->datos($articulo);
        }
        
        public function bcodigo($articulo =''){
            return  $this->model->bcodigo($articulo);
        }
        
        public function bccodigo($articulo =''){
            return  $this->model->bccodigo($articulo);
        }
        public function margenCodigo($articulo =''){
            return  $this->model->margenCodigo($articulo);
        }
        
        public function articulosd($articulo =''){
            return  $this->model->articulosd($articulo);
        }
        public function margen($articulo_data=array()){
             return  $this->model->margen($articulo_data);
        }
        public function editDetalles($articulo_data=array()){
             return  $this->model->editDetalles($articulo_data);
        }
        
        public function contarArticulos(){
             return  $this->model->contarArticulos();
        }
        
        
    }
?>
